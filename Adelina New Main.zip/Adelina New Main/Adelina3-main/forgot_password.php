<?php
require_once 'includes/helpers.php';
start_secure_session();
require_once 'includes/db.php';
require_once 'includes/send_mail.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$info = '';
$email = '';
$otpSent = false;
$csrfToken = csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (post_string('action') === 'cancel') {
        // I-clear ang lumang reset session para makapag-request ng bago.
        unset(
            $_SESSION['reset_user_id'],
            $_SESSION['reset_email'],
            $_SESSION['reset_otp_hash'],
            $_SESSION['reset_otp_expires'],
            $_SESSION['reset_otp_attempts'],
            $_SESSION['reset_otp_sent_at'],
            $_SESSION['reset_stage'],
            $_SESSION['reset_stage_expires']
        );
        $info = 'Na-cancel ang password reset. Puwede ka nang mag-request ulit.';
    } elseif (post_string('action') === 'verify') {
        $email = trim(post_string('email'));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Maglagay ng wastong email.';
        } else {
            // Ang pending na account ay hindi pinapadalhan ng OTP (generic
            // message pa rin ang ipinapakita para walang ma-leak).
            $accountFilter = usersHasAccountStatus($conn) ? " AND account_status = 'approved'" : '';
            $stmt = $conn->prepare(
                "SELECT user_id FROM users
                 WHERE email = ? AND role = 'resident'" . $accountFilter . "
                 LIMIT 1"
            );
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $account = $stmt->get_result()->fetch_assoc();

            if (!$account) {
                // Linisin ang lumang reset session para hindi ito makalito.
                unset(
                    $_SESSION['reset_user_id'],
                    $_SESSION['reset_email'],
                    $_SESSION['reset_otp_hash'],
                    $_SESSION['reset_otp_expires'],
                    $_SESSION['reset_otp_attempts'],
                    $_SESSION['reset_otp_sent_at'],
                    $_SESSION['reset_stage'],
                    $_SESSION['reset_stage_expires']
                );
                // Hindi sinasabi kung may account o wala ang email, para hindi
                // magamit ang page sa paghula ng mga rehistradong email.
                $info = 'Kung may resident account ang email na ito, may OTP na ipinadala.';
            } else {
                $_SESSION['reset_user_id'] = (int) $account['user_id'];
                $_SESSION['reset_email'] = $email;
                $otp = (string) random_int(100000, 999999);
                $_SESSION['reset_otp_hash'] = hash('sha256', $otp);
                $_SESSION['reset_otp_expires'] = time() + 600;
                $_SESSION['reset_otp_attempts'] = 0;
                $_SESSION['reset_otp_sent_at'] = time();

                try {
                    sendGmailOtp($email, $otp);
                    $otpSent = true;
                    $_SESSION['reset_stage'] = 'otp';
                } catch (Throwable $exception) {
                    error_log('Gmail OTP send failed: ' . $exception->getMessage());
                    $error = 'Hindi maipadala ang OTP sa email ngayon. Subukan muli.';
                    unset(
                        $_SESSION['reset_user_id'],
                        $_SESSION['reset_email'],
                        $_SESSION['reset_otp_hash'],
                        $_SESSION['reset_otp_expires'],
                        $_SESSION['reset_otp_attempts'],
                        $_SESSION['reset_stage']
                    );
                }
            }
        }
    } elseif (post_string('action') === 'otp') {
        $enteredOtp = preg_replace('/\D/', '', post_string('otp'));
        $otpHash = (string) ($_SESSION['reset_otp_hash'] ?? '');
        $expires = (int) ($_SESSION['reset_otp_expires'] ?? 0);
        $attempts = (int) ($_SESSION['reset_otp_attempts'] ?? 0);

        if (($_SESSION['reset_stage'] ?? '') !== 'otp' || $otpHash === '') {
            $error = 'Kailangan munang mag-request ng bagong OTP.';
        } elseif (time() > $expires) {
            $error = 'Nag-expire ang OTP. Mag-request ng bagong code.';
            unset(
                $_SESSION['reset_user_id'],
                $_SESSION['reset_email'],
                $_SESSION['reset_otp_hash'],
                $_SESSION['reset_otp_expires'],
                $_SESSION['reset_otp_attempts'],
                $_SESSION['reset_otp_sent_at'],
                $_SESSION['reset_stage'],
                $_SESSION['reset_stage_expires']
            );
        } elseif ($attempts >= 5) {
            $error = 'Masyadong maraming maling attempt. Mag-request ng bagong OTP.';
        } elseif (!hash_equals($otpHash, hash('sha256', $enteredOtp))) {
            $_SESSION['reset_otp_attempts'] = $attempts + 1;
            $error = 'Mali ang OTP code.';
        } else {
            $_SESSION['reset_stage'] = 'reset';
            $_SESSION['reset_stage_expires'] = time() + 600;
            unset($_SESSION['reset_otp_hash'], $_SESSION['reset_otp_expires'], $_SESSION['reset_otp_attempts']);
        }
    } elseif (post_string('action') === 'resend') {
        $resetEmail = (string) ($_SESSION['reset_email'] ?? '');
        $resetUserId = (int) ($_SESSION['reset_user_id'] ?? 0);
        if ($resetEmail === '' || $resetUserId <= 0) {
            $error = 'Mag-request muna ng password reset.';
        } elseif (time() - (int) ($_SESSION['reset_otp_sent_at'] ?? 0) < 60) {
            // Pinipigilan ang paulit-ulit na resend: hindi rin nito nire-reset
            // ang attempt counter nang walang 60 segundong pagitan.
            $error = 'Maghintay ng 60 segundo bago mag-request muli ng OTP.';
        } else {
            $otp = (string) random_int(100000, 999999);
            $_SESSION['reset_otp_hash'] = hash('sha256', $otp);
            $_SESSION['reset_otp_expires'] = time() + 600;
            $_SESSION['reset_otp_attempts'] = 0;
            $_SESSION['reset_otp_sent_at'] = time();
            try {
                sendGmailOtp($resetEmail, $otp);
                $otpSent = true;
                $_SESSION['reset_stage'] = 'otp';
            } catch (Throwable $exception) {
                error_log('Gmail OTP resend failed: ' . $exception->getMessage());
                $error = 'Hindi maipadala ang bagong OTP.';
            }
        }
    } elseif (post_string('action') === 'reset') {
        $newPassword = post_string('new_password');
        $confirmPassword = post_string('confirm_password');
        $resetUserId = (int) ($_SESSION['reset_user_id'] ?? 0);
        $confirmEmail = strtolower(trim(post_string('email')));
        $resetEmailForCheck = strtolower((string) ($_SESSION['reset_email'] ?? ''));
        $stageExpires = (int) ($_SESSION['reset_stage_expires'] ?? 0);

        if ($resetUserId <= 0 || ($_SESSION['reset_stage'] ?? '') !== 'reset') {
            $error = 'Nag-expire ang reset session. I-verify muli ang account.';
        } elseif ($stageExpires > 0 && time() > $stageExpires) {
            $error = 'Nag-expire ang reset session. Mag-request ulit ng bagong OTP.';
            unset(
                $_SESSION['reset_user_id'],
                $_SESSION['reset_email'],
                $_SESSION['reset_otp_hash'],
                $_SESSION['reset_otp_expires'],
                $_SESSION['reset_otp_attempts'],
                $_SESSION['reset_otp_sent_at'],
                $_SESSION['reset_stage'],
                $_SESSION['reset_stage_expires']
            );
        } elseif ($resetEmailForCheck === '' || $confirmEmail !== $resetEmailForCheck) {
            $error = 'Hindi tugma ang email sa account na naka-request ng reset. Suriin ang email at subukan ulit.';
        } elseif (!isValidNewPassword($newPassword)) {
            $error = 'Ang password ay dapat 12 hanggang 64 character.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'Hindi magkatugma ang dalawang password.';
        } else {
            $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $conn->prepare(
                "UPDATE users SET password = ? WHERE user_id = ? AND role = 'resident'"
            );
            $stmt->bind_param('si', $passwordHash, $resetUserId);
            $stmt->execute();

            unset(
                $_SESSION['reset_user_id'],
                $_SESSION['reset_email'],
                $_SESSION['reset_stage'],
                $_SESSION['reset_stage_expires'],
                $_SESSION['reset_otp_sent_at']
            );
            session_regenerate_id(true);
            header('Location: login.php?password_reset=1');
            exit;
        }
    } else {
        $error = 'Hindi wasto ang reset request.';
    }
}

$resetStage = $_SESSION['reset_stage'] ?? '';
$resetEmail = (string) ($_SESSION['reset_email'] ?? '');
$showOtpForm = $resetStage === 'otp';
$showResetForm = $resetStage === 'reset';

// Kapag lumipas na ang 10 minuto mula nang ma-verify ang OTP, hindi na
// puwedeng ituloy ang pag-reset — mag-request ulit ng bagong OTP.
if ($showResetForm) {
    $stageExpiresAtRender = (int) ($_SESSION['reset_stage_expires'] ?? 0);
    if ($stageExpiresAtRender > 0 && time() > $stageExpiresAtRender) {
        unset(
            $_SESSION['reset_user_id'],
            $_SESSION['reset_email'],
            $_SESSION['reset_otp_hash'],
            $_SESSION['reset_otp_expires'],
            $_SESSION['reset_otp_attempts'],
            $_SESSION['reset_otp_sent_at'],
            $_SESSION['reset_stage'],
            $_SESSION['reset_stage_expires']
        );
        $resetStage = '';
        $resetEmail = '';
        $showResetForm = false;
        $error = 'Nag-expire ang reset session. Mag-request ulit ng bagong OTP.';
    }
}
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Forgot Password | Adelina 3 Homeowners Association</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head>
<body class="auth-page">
  <main class="login-wrap">
    <section class="login-card">
      <h1>Forgot Password</h1>
      <p class="muted">I-reset ang password ng resident account.</p>
      <?php if ($error !== ''): ?>
        <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
      <?php endif; ?>
      <?php if ($info !== ''): ?>
        <p class="alert alert-success" role="status"><?= htmlspecialchars($info, ENT_QUOTES, 'UTF-8') ?></p>
      <?php endif; ?>
      <?php if ($otpSent): ?>
        <p class="alert alert-success" role="status">Naipadala ang 6-digit OTP sa Gmail account mo.</p>
      <?php endif; ?>

      <?php if ($showResetForm): ?>
        <form action="forgot_password.php" method="post">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="action" value="reset">
          <label for="resetAccountEmail">Email ng Account</label>
          <input id="resetAccountEmail" type="email" name="email" autocomplete="email" required>
          <small class="muted">I-type ulit ang email ng account na ito para kumpirmahin.</small>
          <label for="newPassword">Bagong Password</label>
          <div class="password-field">
            <input id="newPassword" type="password" name="new_password" minlength="12" maxlength="64" autocomplete="new-password" required>
            <button type="button" class="password-toggle" data-password-toggle="newPassword" aria-controls="newPassword" aria-label="Ipakita ang password" aria-pressed="false">
              <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
            </button>
          </div>
          <label for="confirmPassword">Kumpirmahin ang Password</label>
          <div class="password-field">
            <input id="confirmPassword" type="password" name="confirm_password" minlength="12" maxlength="64" autocomplete="new-password" required>
            <button type="button" class="password-toggle" data-password-toggle="confirmPassword" aria-controls="confirmPassword" aria-label="Ipakita ang password" aria-pressed="false">
              <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
            </button>
          </div>
          <small class="muted">Dapat 12 hanggang 64 character ang password.</small>
          <button type="submit" class="btn btn-primary btn-block">I-reset ang Password</button>
        </form>
        <?php if ($resetEmail !== ''): ?>
          <p class="muted">Para sa account: <?= htmlspecialchars($resetEmail, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>
        <form action="forgot_password.php" method="post" style="margin-top:10px;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="action" value="cancel">
          <button type="submit" class="btn btn-block">Gumamit ng ibang email</button>
        </form>
      <?php elseif ($showOtpForm): ?>
        <form action="forgot_password.php" method="post">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="action" value="otp">
          <label for="otpCode">6-digit OTP Code</label>
          <input id="otpCode" type="text" name="otp" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required>
          <button type="submit" class="btn btn-primary btn-block">I-verify ang OTP</button>
        </form>
        <form action="forgot_password.php" method="post" style="margin-top:10px;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="action" value="resend">
          <button type="submit" class="btn btn-block">Magpadala muli ng OTP</button>
        </form>
        <?php if ($resetEmail !== ''): ?>
          <p class="muted">Naipadala ang OTP sa: <?= htmlspecialchars($resetEmail, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>
        <form action="forgot_password.php" method="post" style="margin-top:10px;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="action" value="cancel">
          <button type="submit" class="btn btn-block">Gumamit ng ibang email</button>
        </form>
      <?php else: ?>
        <form action="forgot_password.php" method="post">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="action" value="verify">
          <label for="resetEmail">Email</label>
          <input id="resetEmail" type="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" autocomplete="email" required>
          <button type="submit" class="btn btn-primary btn-block">Magpatuloy</button>
        </form>
      <?php endif; ?>

      <p class="muted"><a href="login.php">Bumalik sa Login</a></p>
    </section>
  </main>
  <script src="assets/js/script.js?v=<?= (int) filemtime(__DIR__ . '/assets/js/script.js') ?>"></script>
</body>
</html>
