// Adelina 3 HOA — script.js
// Pinagsasama ang maliliit na UI behavior na ginagamit sa mga page ng application.

// Tanggalin ang lumang service worker cache para hindi ma-override ang mga bagong update sa PHP pages.
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(function (registrations) {
    registrations.forEach(function (registration) {
      registration.unregister();
    });
  });
  if ('caches' in window) {
    caches.keys().then(function (names) {
      names.forEach(function (name) {
        caches.delete(name);
      });
    });
  }
}

document.addEventListener('DOMContentLoaded', function () {
  var reportSearch = document.getElementById('reportSearch');
  var reportSearchNoMatch = document.getElementById('reportSearchNoMatch');
  if (reportSearch) {
    var reportRows = Array.from(document.querySelectorAll('.report-section .report-table tbody tr'))
      .filter(function (row) {
        return !row.querySelector('td[colspan]');
      });
    reportSearch.addEventListener('input', function () {
      var searchTerm = reportSearch.value.trim().toLowerCase();
      var visibleRows = 0;
      reportRows.forEach(function (row) {
        var matches = row.textContent.toLowerCase().includes(searchTerm);
        row.hidden = !matches;
        if (matches) visibleRows++;
      });
      if (reportSearchNoMatch) {
        reportSearchNoMatch.hidden = searchTerm === '' || reportRows.length === 0 || visibleRows > 0;
      }
    });
  }

  var printReportButton = document.getElementById('printReportButton');
  if (printReportButton) {
    printReportButton.addEventListener('click', function () {
      window.print();
    });
  }

  var paymentResidentSearch = document.getElementById('paymentResidentSearch');
  var paymentResidentId = document.getElementById('paymentResidentId');
  var paymentResidentOptions = document.getElementById('paymentResidentOptions');
  if (paymentResidentSearch && paymentResidentId && paymentResidentOptions) {
    var matchPaymentResident = function () {
      var searchValue = paymentResidentSearch.value.trim().toLowerCase();
      var matchedOption = Array.from(paymentResidentOptions.options).find(function (option) {
        return option.value.toLowerCase() === searchValue;
      });
      paymentResidentId.value = matchedOption ? matchedOption.dataset.residentId : '';
      paymentResidentSearch.setCustomValidity(
        searchValue !== '' && !matchedOption
          ? 'Pumili ng Block at Lot mula sa mga mungkahi.'
          : ''
      );
    };
    paymentResidentSearch.addEventListener('input', matchPaymentResident);
    paymentResidentSearch.addEventListener('change', matchPaymentResident);
  }

  // Cookie consent banner
  var cookieBanner = document.getElementById('cookieBanner');
  var cookieAccept = document.getElementById('cookieAccept');
  var cookieDecline = document.getElementById('cookieDecline');
  if (cookieBanner && cookieAccept && cookieDecline) {
    var consentKey = 'adelina3-cookie-consent';
    var savedConsent = null;
    try { savedConsent = localStorage.getItem(consentKey); } catch (error) { savedConsent = null; }
    if (!savedConsent) {
      cookieBanner.hidden = false;
    }
    var saveConsent = function (value) {
      try { localStorage.setItem(consentKey, value); } catch (error) { /* localStorage unavailable */ }
      cookieBanner.hidden = true;
    };
    cookieAccept.addEventListener('click', function () { saveConsent('accepted'); });
    cookieDecline.addEventListener('click', function () { saveConsent('declined'); });
  }

  var loginPassword = document.getElementById('password');
  var loginStrengthBar = document.getElementById('login-strength-bar');
  var loginStrengthText = document.getElementById('login-strength-text');
  if (loginPassword && loginStrengthBar && loginStrengthText) {
    var updateLoginStrength = function () {
      var length = loginPassword.value.length;
      var strength = Math.min(100, Math.round((length / 12) * 100));
      loginStrengthBar.style.width = strength + '%';
      loginStrengthBar.classList.toggle('is-short', length > 0 && length < 12);
      loginStrengthBar.classList.toggle('is-ready', length >= 12);
      loginStrengthText.textContent = length === 0
        ? 'Use at least 12 characters for a stronger password.'
        : length < 12
          ? 'Password is short (' + length + '/12 characters).'
          : 'Minimum password length met (' + length + ' characters).';
    };
    loginPassword.addEventListener('input', updateLoginStrength);
    updateLoginStrength();
  }

  document.querySelectorAll('.resident-payment-table .table').forEach(function (table) {
    var labels = Array.from(table.querySelectorAll('thead th')).map(function (heading) {
      return heading.textContent.trim() === 'Date Need to Pay' ? 'Due Date' : heading.textContent.trim();
    });
    table.querySelectorAll('tbody tr').forEach(function (row) {
      Array.from(row.cells).forEach(function (cell, index) {
        if (labels[index]) cell.setAttribute('data-label', labels[index]);
      });
    });
  });

  document.querySelectorAll('.admin-responsive-table .table').forEach(function (table) {
    var labels = Array.from(table.querySelectorAll('thead th')).map(function (heading) {
      return heading.textContent.trim();
    });
    table.querySelectorAll('tbody tr').forEach(function (row) {
      Array.from(row.cells).forEach(function (cell, index) {
        if (labels[index] && !cell.hasAttribute('colspan')) {
          cell.setAttribute('data-label', labels[index]);
        }
      });
    });
  });

  document.querySelectorAll('.complaint-list .table').forEach(function (table) {
    var labels = Array.from(table.querySelectorAll('thead th')).map(function (heading) {
      return heading.textContent.trim();
    });
    table.querySelectorAll('tbody tr').forEach(function (row) {
      Array.from(row.cells).forEach(function (cell, index) {
        if (labels[index] && !cell.hasAttribute('colspan')) {
          cell.setAttribute('data-label', labels[index]);
        }
      });
    });
  });

  document.querySelectorAll('.reservation-table').forEach(function (table) {
    var labels = Array.from(table.querySelectorAll('thead th')).map(function (heading) {
      return heading.textContent.trim();
    });
    table.querySelectorAll('tbody tr').forEach(function (row) {
      Array.from(row.cells).forEach(function (cell, index) {
        if (labels[index] && !cell.hasAttribute('colspan')) {
          cell.setAttribute('data-label', labels[index]);
        }
      });
    });
  });

  document.querySelectorAll('.report-table').forEach(function (table) {
    var labels = Array.from(table.querySelectorAll('thead th')).map(function (heading) {
      return heading.textContent.trim();
    });
    table.querySelectorAll('tbody tr').forEach(function (row) {
      Array.from(row.cells).forEach(function (cell, index) {
        if (labels[index] && !cell.hasAttribute('colspan')) {
          cell.setAttribute('data-label', labels[index]);
        }
      });
    });
  });

  var btn = document.getElementById('menuBtn');
  var sidebar = document.getElementById('sidebar');
  var sidebarBack = document.getElementById('sidebarBack');
  var sidebarBackdrop = document.getElementById('sidebarBackdrop');

  // Nagpapalit sa password field sa pagitan ng plain text at mask.
  document.querySelectorAll('[data-password-toggle]').forEach(function (toggle) {
    toggle.addEventListener('click', function () {
      var inputId = toggle.getAttribute('data-password-toggle');
      var input = document.getElementById(inputId);
      if (!input) {
        return;
      }

      var showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      toggle.setAttribute('aria-pressed', String(!showing));
      toggle.setAttribute('aria-label', showing ? 'Ipakita ang password' : 'Itago ang password');
    });
  });

  var hasUnrealisticDigitPattern = function (digits, minimumRepeatedDigits) {
    var repeatedPattern = new RegExp('([0-9])\\1{' + (minimumRepeatedDigits - 1) + ',}');
    if (repeatedPattern.test(digits)) {
      return true;
    }

    return ['01234567', '12345678', '23456789', '98765432', '87654321', '76543210']
      .some(function (sequence) {
        return digits.indexOf(sequence) !== -1;
      });
  };

  document.querySelectorAll('[data-validate-ph-mobile]').forEach(function (input) {
    var validateMobile = function () {
      var value = input.value.trim();
      var validFormat = /^09[0-9]{9}$/.test(value);
      var plausibleDigits = validFormat && !hasUnrealisticDigitPattern(value.slice(2), 8);
      input.setCustomValidity(value !== '' && !plausibleDigits
        ? 'Maglagay ng kapani-paniwalang 11-digit mobile number na nagsisimula sa 09.'
        : '');
    };
    input.addEventListener('input', validateMobile);
    input.addEventListener('blur', validateMobile);
    validateMobile();
  });

  document.querySelectorAll('[data-validate-block-lot]').forEach(function (input) {
    var validateBlockLot = function () {
      var value = input.value.trim();
      var digits = value.replace(/[^0-9]/g, '');
      var plausible = digits !== '' && !hasUnrealisticDigitPattern(digits, 5);
      input.setCustomValidity(value !== '' && !plausible
        ? 'Maglagay ng wastong Block/Lot. Iwasan ang puro magkakapareho o sunod-sunod na numero.'
        : '');
    };
    input.addEventListener('input', validateBlockLot);
    input.addEventListener('blur', validateBlockLot);
    validateBlockLot();
  });

  // Complaints form: laging aktibo kahit pagkatapos mag-submit o mag-reload ang page.
  var syncComplaintsForm = function () {
    var reportTypeSelect = document.getElementById('reportType');
    var complaintBlk = document.getElementById('complaintBlk');
    var complaintLot = document.getElementById('complaintLot');
    var complaintStreet = document.getElementById('complaintStreet');
    var complaintCategory = document.getElementById('complaintCategory');
    var otherSpecifyWrap = document.getElementById('otherSpecifyWrap');
    var otherSpecifyInput = document.getElementById('otherSpecifyInput');

    if (reportTypeSelect && complaintBlk && complaintLot && complaintStreet) {
      if (reportTypeSelect.value === 'Suggestion') {
        var uBlk = complaintBlk.getAttribute('data-user-blk') || '';
        var uLot = complaintLot.getAttribute('data-user-lot') || '';
        var uStreet = complaintStreet.getAttribute('data-user-street') || '';
        if (uBlk !== '') complaintBlk.value = uBlk;
        if (uLot !== '') complaintLot.value = uLot;
        if (uStreet !== '') complaintStreet.value = uStreet;
      }
    }

    if (complaintCategory && otherSpecifyWrap && otherSpecifyInput) {
      var isOthers = complaintCategory.value === 'Others';
      otherSpecifyWrap.hidden = !isOthers;
      otherSpecifyWrap.style.display = isOthers ? 'flex' : 'none';
      if (isOthers) {
        otherSpecifyWrap.style.flexDirection = 'column';
      }
      otherSpecifyInput.required = isOthers;
      if (!isOthers) {
        otherSpecifyInput.value = '';
      }
    }
  };

  document.addEventListener('change', function (event) {
    if (event.target && (event.target.id === 'reportType' || event.target.id === 'complaintCategory')) {
      syncComplaintsForm();
    }
  });

  window.addEventListener('pageshow', syncComplaintsForm);
  syncComplaintsForm();

  // Binubuksan o isinasara ang sidebar sa mobile at ina-update ang accessibility state.
  if (btn && sidebar) {
    var setSidebarOpen = function (isOpen) {
      sidebar.classList.toggle('is-open', isOpen);
      btn.setAttribute('aria-expanded', String(isOpen));
      document.body.classList.toggle('menu-open', isOpen);
      if (sidebarBackdrop) {
        sidebarBackdrop.hidden = !isOpen;
      }
      if (isOpen && sidebarBack) {
        sidebarBack.focus();
      } else {
        btn.focus();
      }
    };

    btn.addEventListener('click', function () {
      setSidebarOpen(!sidebar.classList.contains('is-open'));
    });

    if (sidebarBack) {
      sidebarBack.addEventListener('click', function () {
        setSidebarOpen(false);
      });
    }

    if (sidebarBackdrop) {
      sidebarBackdrop.addEventListener('click', function () {
        setSidebarOpen(false);
      });
    }

    sidebar.querySelectorAll('nav a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth <= 900 && sidebar.classList.contains('is-open')) {
          setSidebarOpen(false);
        }
      });
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && sidebar.classList.contains('is-open')) {
        setSidebarOpen(false);
      }
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 900 && sidebar.classList.contains('is-open')) {
        setSidebarOpen(false);
      }
    });
  }

  var paymentOption = document.getElementById('residentPaymentOption');
  var onlineReferenceField = document.getElementById('onlineReferenceField');
  var onlineProofField = document.getElementById('onlineProofField');
  var paymentReference = document.getElementById('paymentReference');
  var paymentReferenceHelp = document.getElementById('paymentReferenceHelp');
  var paymentProof = document.getElementById('paymentProof');

  if (paymentOption && onlineReferenceField && onlineProofField) {
    var updateOnlineFields = function () {
      var online = paymentOption.value === 'GCash' || paymentOption.value === 'Online Bank';
      onlineReferenceField.hidden = !online;
      onlineProofField.hidden = false;
      paymentReference.required = online;
      paymentProof.required = online;
      if (paymentOption.value === 'GCash') {
        paymentReference.pattern = '[0-9]{13}';
        paymentReference.maxLength = 13;
        paymentReference.title = 'Enter exactly 13 digits.';
        paymentReference.placeholder = '13 digits';
        paymentReferenceHelp.textContent = 'GCash reference number: exactly 13 digits.';
      } else {
        paymentReference.pattern = '[0-9]{1,100}';
        paymentReference.maxLength = 100;
        paymentReference.title = 'Digits only, up to 100 digits.';
        paymentReference.placeholder = 'Digits only';
        paymentReferenceHelp.textContent = 'Online bank reference lengths vary. Enter the digits shown by your bank.';
      }
    };
    paymentOption.addEventListener('change', updateOnlineFields);
    updateOnlineFields();
  }

  // Nagbibigay ng preview at client-side adjustments para sa image attachments.
  document.querySelectorAll('[data-image-editor]').forEach(function (editor) {
    var input = document.getElementById(editor.getAttribute('data-image-input'));
    var form = input ? input.closest('form') : null;
    var canvas = editor.querySelector('[data-image-canvas]');
    var context = canvas ? canvas.getContext('2d') : null;
    var crop = editor.querySelector('[data-image-crop]');
    var brightness = editor.querySelector('[data-image-brightness]');
    var contrast = editor.querySelector('[data-image-contrast]');
    var brightnessValue = editor.querySelector('[data-image-brightness-value]');
    var contrastValue = editor.querySelector('[data-image-contrast-value]');
    var status = editor.querySelector('[data-image-status]');
    var maxOutputSize = Number(editor.getAttribute('data-max-output-size'));
    var sourceImage = null;
    var objectUrl = '';
    var rotation = 0;
    var hasChanges = false;
    var imageReady = false;
    var submitting = false;
    var readyToSubmit = false;
    var loadSequence = 0;
    var maxImageDimension = 3000;

    if (!input || !form || !canvas || !context || !crop || !brightness || !contrast || !status) {
      return;
    }

    var setStatus = function (message) {
      status.textContent = message;
    };

    var renderPreview = function () {
      if (!sourceImage || !imageReady) {
        return;
      }

      var scale = Math.min(
        1,
        maxImageDimension / Math.max(sourceImage.naturalWidth, sourceImage.naturalHeight)
      );
      var sourceWidth = Math.max(1, Math.round(sourceImage.naturalWidth * scale));
      var sourceHeight = Math.max(1, Math.round(sourceImage.naturalHeight * scale));
      var normalizedRotation = ((rotation % 360) + 360) % 360;
      var rotatedWidth = normalizedRotation % 180 === 0 ? sourceWidth : sourceHeight;
      var rotatedHeight = normalizedRotation % 180 === 0 ? sourceHeight : sourceWidth;
      var rotatedCanvas = document.createElement('canvas');
      rotatedCanvas.width = rotatedWidth;
      rotatedCanvas.height = rotatedHeight;
      var rotatedContext = rotatedCanvas.getContext('2d');

      if (!rotatedContext) {
        setStatus('Hindi maipakita ang preview sa browser na ito.');
        return;
      }

      rotatedContext.translate(rotatedWidth / 2, rotatedHeight / 2);
      rotatedContext.rotate(normalizedRotation * Math.PI / 180);
      rotatedContext.drawImage(sourceImage, -sourceWidth / 2, -sourceHeight / 2, sourceWidth, sourceHeight);

      var cropWidth = rotatedWidth;
      var cropHeight = rotatedHeight;
      if (crop.value !== 'free') {
        var ratioParts = crop.value.split(':');
        var cropRatio = Number(ratioParts[0]) / Number(ratioParts[1]);
        if (cropWidth / cropHeight > cropRatio) {
          cropWidth = Math.round(cropHeight * cropRatio);
        } else {
          cropHeight = Math.round(cropWidth / cropRatio);
        }
      }

      var cropX = Math.floor((rotatedWidth - cropWidth) / 2);
      var cropY = Math.floor((rotatedHeight - cropHeight) / 2);
      canvas.width = cropWidth;
      canvas.height = cropHeight;
      context = canvas.getContext('2d');
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, cropWidth, cropHeight);
      context.filter = 'brightness(' + brightness.value + '%) contrast(' + contrast.value + '%)';
      context.drawImage(
        rotatedCanvas,
        cropX,
        cropY,
        cropWidth,
        cropHeight,
        0,
        0,
        cropWidth,
        cropHeight
      );
      context.filter = 'none';
    };

    var updateFilterReadouts = function () {
      if (brightnessValue) brightnessValue.textContent = brightness.value + '%';
      if (contrastValue) contrastValue.textContent = contrast.value + '%';
    };

    var markEditedAndRender = function () {
      hasChanges = true;
      renderPreview();
      setStatus('Kapag in-edit, ise-save bilang JPEG hanggang 3000 px; magiging still image ang GIF.');
    };

    input.addEventListener('change', function () {
      loadSequence += 1;
      var currentLoad = loadSequence;
      sourceImage = null;
      hasChanges = false;
      rotation = 0;
      if (objectUrl) {
        window.URL.revokeObjectURL(objectUrl);
        objectUrl = '';
      }

      var selectedFile = input.files && input.files[0];
      if (!selectedFile) {
        imageReady = false;
        editor.hidden = true;
        return;
      }

      var extension = selectedFile.name.split('.').pop().toLowerCase();
      var supportedImage = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'].includes(selectedFile.type)
        || (!selectedFile.type && ['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(extension));
      if (!supportedImage) {
        imageReady = false;
        editor.hidden = true;
        return;
      }

      imageReady = false;
      brightness.value = '100';
      contrast.value = '100';
      updateFilterReadouts();
      crop.value = 'free';
      editor.hidden = false;
      setStatus('Inihahanda ang image preview...');
      objectUrl = window.URL.createObjectURL(selectedFile);
      sourceImage = new Image();
      sourceImage.onload = function () {
        if (currentLoad !== loadSequence) {
          return;
        }
        imageReady = true;
        renderPreview();
        setStatus(hasChanges
          ? 'Kapag in-edit, ise-save bilang JPEG hanggang 3000 px; magiging still image ang GIF.'
          : 'Preview ito ng napiling image. Hindi mababago ang upload hangga’t hindi ina-adjust.');
      };
      sourceImage.onerror = function () {
        if (currentLoad === loadSequence) {
          sourceImage = null;
          imageReady = false;
          setStatus('Hindi mabasa ang image para sa preview. Maaari kang pumili ng ibang image.');
        }
      };
      sourceImage.src = objectUrl;
    });

    crop.addEventListener('change', markEditedAndRender);
    brightness.addEventListener('input', function () { updateFilterReadouts(); markEditedAndRender(); });
    contrast.addEventListener('input', function () { updateFilterReadouts(); markEditedAndRender(); });

    editor.querySelectorAll('[data-image-rotate]').forEach(function (button) {
      button.addEventListener('click', function () {
        rotation += Number(button.getAttribute('data-image-rotate'));
        markEditedAndRender();
      });
    });

    var resetButton = editor.querySelector('[data-image-reset]');
    if (resetButton) {
      resetButton.addEventListener('click', function () {
        rotation = 0;
        crop.value = 'free';
        brightness.value = '100';
        contrast.value = '100';
        updateFilterReadouts();
        hasChanges = false;
        renderPreview();
        setStatus('Nai-reset ang edits. Original image ang ipapadala.');
      });
    }

    form.addEventListener('submit', function (event) {
      if (readyToSubmit) {
        readyToSubmit = false;
        return;
      }
      if (!sourceImage || !hasChanges) {
        return;
      }

      event.preventDefault();
      if (!imageReady) {
        setStatus('Hintaying matapos ang image preview bago isumite.');
        return;
      }
      if (submitting) {
        return;
      }

      submitting = true;
      setStatus('Inihahanda ang edited image...');
      canvas.toBlob(function (blob) {
        if (!blob) {
          submitting = false;
          setStatus('Hindi maihanda ang edited image. Subukang muli o i-reset ang edits.');
          return;
        }
        if (blob.size > maxOutputSize) {
          submitting = false;
          setStatus('Lumampas sa pinapayagang file size ang edited image. Bawasan ang crop o pumili ng ibang image.');
          return;
        }

        try {
          var transfer = new DataTransfer();
          transfer.items.add(new File([blob], 'edited-image.jpg', {
            type: 'image/jpeg',
            lastModified: Date.now()
          }));
          input.files = transfer.files;

          var submitter = event.submitter;
          submitting = false;
          if (typeof form.requestSubmit === 'function') {
            readyToSubmit = true;
            if (submitter) {
              form.requestSubmit(submitter);
            } else {
              form.requestSubmit();
            }
          } else {
            if (submitter && submitter.name) {
              var hiddenSubmitter = document.createElement('input');
              hiddenSubmitter.type = 'hidden';
              hiddenSubmitter.name = submitter.name;
              hiddenSubmitter.value = submitter.value;
              form.appendChild(hiddenSubmitter);
            }
            HTMLFormElement.prototype.submit.call(form);
          }
        } catch (error) {
          submitting = false;
          readyToSubmit = false;
          setStatus('Hindi maihanda ang edited image. Gumamit ng updated browser at subukang muli.');
        }
      }, 'image/jpeg', 0.92);
    });
    updateFilterReadouts();
  });

  document.querySelectorAll('[data-post-lock]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (event.defaultPrevented) return;
      var button = form.querySelector('[data-post-button]');
      var label = button && button.querySelector('[data-post-label]');
      if (!button || button.disabled) return;
      button.disabled = true;
      button.classList.add('is-submitting');
      if (label) label.textContent = 'Posting announcement...';
    });
  });

  var reservationMinute = document.getElementById('reservationMinute');
  if (reservationMinute) {
    reservationMinute.addEventListener('input', function () {
      var value = reservationMinute.value;
      if (value !== '' && (!/^[0-9]{1,2}$/.test(value) || Number(value) > 59)) {
        reservationMinute.value = '';
      }
    });
  }

  // Sinasala ang kasalukuyang table rows habang nagta-type ang user.
  var search = document.getElementById('searchInput');
  var table = document.getElementById('dataTable');
  if (search && table) {
    search.addEventListener('input', function () {
      var query = search.value.toLocaleLowerCase();
      var rows = table.querySelectorAll('tbody tr');

      rows.forEach(function (row) {
        row.hidden = !row.textContent.toLocaleLowerCase().includes(query);
      });
    });
  }

  // Binabalaan ang user bago ipadala ang mga form na may confirmation message.
  document.querySelectorAll('.confirm-form').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      var message = form.getAttribute('data-confirm') || 'Sigurado ka ba?';
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  });

  document.querySelectorAll('.confirm-link').forEach(function (link) {
    link.addEventListener('click', function (event) {
      var message = link.getAttribute('data-confirm') || 'Sigurado ka ba?';
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  });

  var imageLightbox = document.querySelector('[data-complaint-image-lightbox]');
  var largeComplaintImage = document.querySelector('[data-complaint-image-large]');
  var closeImageLightbox = document.querySelector('[data-complaint-image-close]');
  if (imageLightbox && largeComplaintImage && closeImageLightbox) {
    var activeImageButton = null;
    var imageHoldTimer = null;
    var holdStartedAt = null;
    var holdTriggered = false;
    var ignoreBackdropClick = false;
    var lightboxOpenedAt = 0;

    var closeLightbox = function () {
      imageLightbox.hidden = true;
      largeComplaintImage.removeAttribute('src');
      document.body.classList.remove('complaint-image-open');
      holdTriggered = false;
      if (activeImageButton) {
        activeImageButton.focus();
        activeImageButton = null;
      }
    };

    var showHeldImage = function (button, triggeredByHold) {
      var image = button.querySelector('img');
      if (!image) {
        return;
      }
      holdTriggered = triggeredByHold;
      activeImageButton = button;
      largeComplaintImage.src = image.src;
      largeComplaintImage.alt = 'Pinalaking larawan ng complaint';
      imageLightbox.hidden = false;
      lightboxOpenedAt = Date.now();
      document.body.classList.add('complaint-image-open');
      closeImageLightbox.focus();
    };

    var cancelImageHold = function () {
      if (imageHoldTimer !== null) {
        window.clearTimeout(imageHoldTimer);
        imageHoldTimer = null;
      }
      holdStartedAt = null;
    };

    document.querySelectorAll('[data-hold-image-preview]').forEach(function (button) {
      button.addEventListener('pointerdown', function (event) {
        if (event.pointerType === 'mouse' && event.button !== 0) {
          return;
        }
        cancelImageHold();
        holdTriggered = false;
        holdStartedAt = { x: event.clientX, y: event.clientY };
        imageHoldTimer = window.setTimeout(function () {
          imageHoldTimer = null;
          showHeldImage(button, true);
        }, 500);
      });

      button.addEventListener('pointermove', function (event) {
        if (
          holdStartedAt
          && (Math.abs(event.clientX - holdStartedAt.x) > 12
            || Math.abs(event.clientY - holdStartedAt.y) > 12)
        ) {
          cancelImageHold();
        }
      });

      button.addEventListener('pointerup', cancelImageHold);
      button.addEventListener('pointerleave', cancelImageHold);
      button.addEventListener('pointercancel', cancelImageHold);
      button.addEventListener('contextmenu', function (event) {
        event.preventDefault();
      });
      button.addEventListener('click', function (event) {
        if (holdTriggered) {
          event.preventDefault();
          holdTriggered = false;
        } else if (event.detail === 0) {
          showHeldImage(button, false);
        }
      });
    });

    document.addEventListener('pointerup', function () {
      if (holdTriggered) {
        ignoreBackdropClick = true;
        window.setTimeout(function () {
          ignoreBackdropClick = false;
        }, 500);
      }
    }, true);

    closeImageLightbox.addEventListener('click', closeLightbox);
    imageLightbox.addEventListener('click', function (event) {
      if (
        event.target === imageLightbox
        && !ignoreBackdropClick
        && Date.now() - lightboxOpenedAt > 300
      ) {
        closeLightbox();
      }
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && !imageLightbox.hidden) {
        closeLightbox();
      }
    });
  }

  // Awtomatikong itinatago ang mga alert matapos ang maikling panahon.
  document.querySelectorAll('.alert').forEach(function (alert) {
    window.setTimeout(function () {
      alert.style.display = 'none';
    }, 4000);
  });

  // Live na bell badge
  var notifBell = document.querySelector('.notif-bell');
  if (notifBell) {
    var updateNotifBadge = function () {
      if (document.hidden) {
        return;
      }
      fetch('notifications_count.php', { credentials: 'same-origin' })
        .then(function (response) { return response.json(); })
        .then(function (data) {
          var count = parseInt(data.unread, 10) || 0;
          var badge = notifBell.querySelector('.notif-badge');
          if (count > 0) {
            if (!badge) {
              badge = document.createElement('span');
              badge.className = 'notif-badge';
              notifBell.appendChild(badge);
            }
            badge.textContent = count > 99 ? '99+' : String(count);
          } else if (badge) {
            badge.remove();
          }
        })
        .catch(function () {});
    };
    updateNotifBadge();
    window.setInterval(updateNotifBadge, 10000);
  }
});