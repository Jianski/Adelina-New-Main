// Adelina 3 HOA — sw.js (service worker)
// Simple at ligtas: static assets lang ang naka-cache (cache-first).
// Lahat ng page at POST request ay laging dumadaan sa network, kaya
// hindi kailanman maipapakita sa ibang user ang naka-login na pahina.
var CACHE_NAME = 'adelina3-hoa-v1';
var STATIC_EXTENSIONS = ['css', 'js', 'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'woff', 'woff2', 'ico', 'webmanifest'];
var PRECACHE_URLS = [
  'assets/images/icon-192.png',
  'assets/images/icon-512.png',
  'assets/images/logo.png',
  'assets/images/logo-icon.png',
  'favicon.png',
  'manifest.webmanifest'
];

// I-cache nang maaga ang mga icon at logo para handa na sa pag-install.
self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      return cache.addAll(PRECACHE_URLS);
    }).catch(function () {
      // Kapag may hindi ma-cache (hal. offline), tuloy pa rin ang install.
    })
  );
});

// Burahin ang mga lumang cache kapag may bagong bersyon ng service worker.
self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.map(function (key) {
        if (key !== CACHE_NAME) {
          return caches.delete(key);
        }
        return Promise.resolve();
      }));
    }).then(function () {
      return self.clients.claim();
    })
  );
});

function isCacheableStatic(request) {
  if (request.method !== 'GET') {
    return false;
  }
  var url;
  try {
    url = new URL(request.url);
  } catch (error) {
    return false;
  }
  if (url.origin !== self.location.origin) {
    return false;
  }
  var path = url.pathname.split('?')[0];
  var dot = path.lastIndexOf('.');
  if (dot === -1) {
    return false;
  }
  var extension = path.slice(dot + 1).toLowerCase();
  return STATIC_EXTENSIONS.indexOf(extension) !== -1;
}

self.addEventListener('fetch', function (event) {
  // GET lang at same-origin static file lang ang pwedeng i-cache.
  // Lahat ng iba pa — mga PHP page, POST, at cross-origin — ay
  // direktang ipinapasa sa network at hindi kailanman naka-cache.
  if (!isCacheableStatic(event.request)) {
    return;
  }
  event.respondWith(
    caches.match(event.request).then(function (cached) {
      if (cached) {
        return cached;
      }
      return fetch(event.request).then(function (response) {
        if (response && response.ok) {
          var copy = response.clone();
          caches.open(CACHE_NAME).then(function (cache) {
            cache.put(event.request, copy);
          });
        }
        return response;
      });
    })
  );
});

/* PUSH-HANDLER-APPEND-POINT */
