<?php
// Resibo ng bayad (PDF): nagdo-download ng PDF receipt para sa isang payment.
// Tanging ang may-ari ng payment (resident) o staff (admin/officer) lang
// ang puwedeng mag-download nito.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$role = $_SESSION['role'] ?? '';
$userId = (int) ($_SESSION['user_id'] ?? 0);

$paymentId = filter_var($_GET['payment_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($paymentId === false) {
    http_response_code(400);
    exit('Hindi wasto ang payment ID.');
}

// Kinukuha ang payment kasama ang may-ari nito (user_id ng resident)
// para masuri ang pagmamay-ari bago maglabas ng anumang detalye.
$stmt = $conn->prepare(
    'SELECT p.payment_id, p.description, p.amount, p.date_paid, p.due_date, p.status,
            p.approval_status, p.payment_method, p.payment_provider, p.payment_reference,
            u.full_name, r.block_lot, r.user_id AS owner_user_id
     FROM payments p
     JOIN residents r ON p.resident_id = r.resident_id
     JOIN users u ON r.user_id = u.user_id
     WHERE p.payment_id = ?'
);
$stmt->bind_param('i', $paymentId);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();

if (!$payment) {
    http_response_code(404);
    exit('Hindi makita ang payment.');
}

// Ownership check: staff (admin/officer) sa lahat ng payment; resident
// sa SARILING payment lang — ikinumpara ang user_id ng may-ari ng
// payment sa naka-login na user. Kapag iba ang may-ari, 403 at WALANG
// file o detalye ng payment na inilalabas.
$isStaff = in_array($role, ['admin', 'officer'], true);
if (!$isStaff && ($role !== 'resident' || (int) $payment['owner_user_id'] !== $userId)) {
    http_response_code(403);
    exit('Walang pahintulot.');
}

// --- Paghahanda ng mga detalye ng resibo ---

$receiptNumber = 'A3-' . str_pad((string) $paymentId, 6, '0', STR_PAD_LEFT);
$fullName = (string) ($payment['full_name'] ?? '');
$blockLot = (string) ($payment['block_lot'] ?? '');
$description = (string) ($payment['description'] ?? '');
$amountText = 'PHP ' . number_format((float) $payment['amount'], 2);

$paymentMethod = (string) ($payment['payment_provider'] ?? '');
if ($paymentMethod === '') {
    $paymentMethod = (string) ($payment['payment_method'] ?? '');
}
if ($paymentMethod === '') {
    $paymentMethod = '—';
}
$paymentReference = trim((string) ($payment['payment_reference'] ?? ''));

$datePaid = (string) ($payment['date_paid'] ?? '');
$dueDate = (string) ($payment['due_date'] ?? '');
$approvalStatus = (string) ($payment['approval_status'] ?? '');
$status = (string) ($payment['status'] ?? '');

// Hindi kailanman magpapakita ng pekeng petsa ng bayad: kapag wala pang
// date_paid, "Hindi pa bayad" ang katayuan at due date ang ipinapakita.
$isPaid = $status === 'Paid' || $datePaid !== '';
if ($isPaid) {
    $statusBanner = 'BAYAD NA';
    $statusDetail = $approvalStatus !== '' ? 'Bayad na (' . $approvalStatus . ')' : 'Bayad na';
} elseif ($approvalStatus === 'Pending') {
    $statusBanner = 'HINDI PA BAYAD';
    $statusDetail = 'Hindi pa bayad (naghihintay ng validation)';
} elseif ($approvalStatus === 'Rejected') {
    $statusBanner = 'HINDI PA BAYAD';
    $statusDetail = 'Hindi pa bayad (na-reject; puwedeng magbayad uli)';
} else {
    $statusBanner = 'HINDI PA BAYAD';
    $statusDetail = 'Hindi pa bayad';
}

$paidDateText = $datePaid !== '' ? date('M d, Y', strtotime($datePaid)) : '';
$dueDateText = $dueDate !== '' ? date('M d, Y', strtotime($dueDate)) : '—';
$generatedText = date('M d, Y h:i A');

// --- Minimal pure-PHP PDF writer (walang library, walang composer) ---
// Isang pahina lang (A4) gamit ang built-in Helvetica / Helvetica-Bold.
// ASCII lang ang kaya ng font na ito, kaya tine-transliterate muna ang
// mga karakter tulad ng ñ at é bago isulat sa PDF.

// Ginagawang ligtas na PDF string ang text: ASCII lang, at ine-escape
// ang backslash at parentheses na may espesyal na kahulugan sa PDF.
function pdf_escape_text(string $text): string
{
    $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
    if (is_string($converted) && $converted !== '') {
        $text = $converted;
    }
    $text = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
    return (string) preg_replace('/[^\x20-\x7E]/', '?', $text);
}

// Hinahati ang mahabang text sa mga linyang kasya sa lapad (points).
// Helvetica ≈ 0.6 × font size ang lapad ng bawat character sa pinaka-
// malapad na tantiya, kaya hindi lalampas sa margin ang text.
function pdf_wrap_text(string $text, float $fontSize, float $maxWidth): array
{
    $maxChars = max(10, (int) floor($maxWidth / ($fontSize * 0.6)));
    $wrapped = wordwrap($text, $maxChars, "\n", true);
    return explode("\n", $wrapped);
}

// Tantiyang x para ma-center ang text sa pahina (lapad ng A4: 595 pt).
function pdf_center_x(string $text, float $fontSize, float $factor = 0.6): float
{
    return (595 - strlen($text) * $fontSize * $factor) / 2;
}

// Bumubuo ng isang pahinang PDF (A4) mula sa mga draw item.
// Bawat item ay text (font/size/x/y/color) o guhit (line/width/color).
function build_simple_pdf(array $items): string
{
    $stream = '';
    foreach ($items as $item) {
        if (isset($item['line'])) {
            [$x1, $y1, $x2, $y2] = $item['line'];
            [$r, $g, $b] = $item['color'];
            $stream .= sprintf(
                '%s %s %s RG %s w %s %s m %s %s l S' . "\n",
                $r, $g, $b, $item['width'], $x1, $y1, $x2, $y2
            );
        } else {
            [$r, $g, $b] = $item['color'];
            $stream .= sprintf(
                'BT /%s %s Tf %s %s %s rg 1 0 0 1 %s %s Tm (%s) Tj ET' . "\n",
                $item['font'], $item['size'], $r, $g, $b,
                $item['x'], $item['y'], pdf_escape_text($item['text'])
            );
        }
    }

    $objects = [];
    $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
    $objects[2] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
    $objects[3] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>';
    $objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
    $objects[5] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>';
    $objects[6] = '<< /Length ' . strlen($stream) . " >>\nstream\n" . $stream . 'endstream';

    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $num => $body) {
        $offsets[$num] = strlen($pdf);
        $pdf .= $num . " 0 obj\n" . $body . "\nendobj\n";
    }
    $xrefPos = strlen($pdf);
    $count = count($objects) + 1;
    $pdf .= 'xref' . "\n" . '0 ' . $count . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i <= count($objects); $i++) {
        $pdf .= sprintf('%010d 00000 n ' . "\n", $offsets[$i]);
    }
    $pdf .= 'trailer' . "\n" . '<< /Size ' . $count . ' /Root 1 0 R >>' . "\n";
    $pdf .= 'startxref' . "\n" . $xrefPos . "\n" . '%%EOF';
    return $pdf;
}

// Nagdadagdag ng isang field (label + value) sa resibo; hinahati ang
// mahabang value sa maraming linya at ibinababa ang cursor ($y).
function receipt_add_field(array &$items, float &$y, string $label, string $value, float $valueSize = 11.0, bool $valueBold = false): void
{
    $dark = [0.12, 0.12, 0.12];
    $valueLines = pdf_wrap_text($value, $valueSize, 329);
    $first = true;
    foreach ($valueLines as $line) {
        if ($first) {
            $items[] = ['text' => $label, 'font' => 'F2', 'size' => 11, 'x' => 56, 'y' => $y, 'color' => $dark];
            $first = false;
        }
        $items[] = ['text' => $line, 'font' => $valueBold ? 'F2' : 'F1', 'size' => $valueSize, 'x' => 210, 'y' => $y, 'color' => $dark];
        $y -= 15;
    }
    $y -= 9;
}

// --- Layout ng resibo (lahat ng y ay relative sa cursor, walang overlap) ---

$green = [0.04, 0.42, 0.24];
$dark = [0.12, 0.12, 0.12];
$muted = [0.35, 0.35, 0.35];
$red = [0.65, 0.12, 0.12];

$items = [];
$y = 792;

$items[] = ['text' => 'ADELINA 3', 'font' => 'F2', 'size' => 22, 'x' => 56, 'y' => $y, 'color' => $green];
$y -= 20;
$items[] = ['text' => 'Homeowners Association', 'font' => 'F1', 'size' => 12, 'x' => 56, 'y' => $y, 'color' => $dark];
$y -= 14;
$items[] = ['line' => [56, $y, 539, $y], 'width' => 2, 'color' => $green];
$y -= 32;

$title = 'RESIBO NG BAYAD';
$items[] = ['text' => $title, 'font' => 'F2', 'size' => 16, 'x' => pdf_center_x($title, 16, 0.62), 'y' => $y, 'color' => $green];
$y -= 22;
$receiptLine = 'Numero ng Resibo: ' . $receiptNumber;
$items[] = ['text' => $receiptLine, 'font' => 'F1', 'size' => 11, 'x' => pdf_center_x($receiptLine, 11), 'y' => $y, 'color' => $dark];
$y -= 22;
$items[] = ['text' => $statusBanner, 'font' => 'F2', 'size' => 13, 'x' => pdf_center_x($statusBanner, 13, 0.62), 'y' => $y, 'color' => $isPaid ? $green : $red];
$y -= 16;
$items[] = ['line' => [56, $y, 539, $y], 'width' => 0.75, 'color' => $muted];
$y -= 26;

receipt_add_field($items, $y, 'Pangalan ng Resident:', $fullName);
receipt_add_field($items, $y, 'Block/Lot:', $blockLot);
receipt_add_field($items, $y, 'Deskripsyon:', $description);
receipt_add_field($items, $y, 'Halaga:', $amountText, 14.0, true);
receipt_add_field($items, $y, 'Paraan ng Pagbayad:', $paymentMethod);
if ($paymentReference !== '') {
    receipt_add_field($items, $y, 'Reference Number:', $paymentReference);
}
if ($isPaid) {
    receipt_add_field($items, $y, 'Petsa ng Bayad:', $paidDateText);
} else {
    receipt_add_field($items, $y, 'Petsa ng Due:', $dueDateText);
}
receipt_add_field($items, $y, 'Katayuan:', $statusDetail);
if ($approvalStatus !== '') {
    receipt_add_field($items, $y, 'Pag-apruba ng Admin:', $approvalStatus);
}
receipt_add_field($items, $y, 'Petsa ng Resibo:', $generatedText);

$y -= 14;
$thanks = 'Salamat sa pagbabayad!';
$items[] = ['text' => $thanks, 'font' => 'F2', 'size' => 12, 'x' => pdf_center_x($thanks, 12), 'y' => $y, 'color' => $green];
$y -= 24;
$items[] = ['line' => [56, $y, 539, $y], 'width' => 0.75, 'color' => $muted];
$y -= 20;
foreach (pdf_wrap_text('Tandaan: Ang resibong ito ay patunay ng bayad na naitala sa Adelina 3 HOA system. Para sa mga katanungan tungkol sa resibong ito, makipag-ugnayan sa HOA officer o admin.', 10.0, 483) as $noteLine) {
    $items[] = ['text' => $noteLine, 'font' => 'F1', 'size' => 10, 'x' => 56, 'y' => $y, 'color' => $muted];
    $y -= 14;
}

// --- Ipadala ang PDF bilang download ---

$pdf = build_simple_pdf($items);
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="resibo-adelina3-' . $paymentId . '.pdf"');
header('X-Content-Type-Options: nosniff');
header('Content-Length: ' . strlen($pdf));
header('Cache-Control: private, max-age=0, must-revalidate');
echo $pdf;
exit;
