<?php
require_once 'includes/helpers.php';
start_secure_session();

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
} else {
    header('Location: landing.php');
}
exit;
