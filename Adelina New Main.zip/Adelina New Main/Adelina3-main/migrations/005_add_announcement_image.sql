ALTER TABLE announcements
  ADD COLUMN image_file VARCHAR(100) NULL AFTER body;
