<?php
// Gumagawa ng bagong resident account at kaugnay na resident profile sa iisang transaction.
require_once 'includes/helpers.php';
start_secure_session();
require_once 'includes/db.php';
require_once 'includes/validation.php';

$error = '';
$fullName = '';
$email = '';
$contactNo = '';
$blk = 1;
$lot = 1;
$street = '';
$csrfToken = csrf_token();

// Sinusuri muna ang mga kinakailangang field bago mag-hash ng password at magsulat sa database.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } else {
        $fullName = trim(post_string('full_name'));
        $email = trim(post_string('email'));
        $contactNo = trim(post_string('contact_no'));

        // Backend validation para sa hiwalay na blk at lot (1 hanggang 100) at street
        $blkInput = filter_input(INPUT_POST, 'blk', FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1, 'max_range' => 100]
        ]);
        $lotInput = filter_input(INPUT_POST, 'lot', FILTER_VALIDATE_INT, [
            'options' => ['min_range' => 1, 'max_range' => 100]
        ]);
        $blk = ($blkInput !== false && $blkInput !== null) ? $blkInput : 0;
        $lot = ($lotInput !== false && $lotInput !== null) ? $lotInput : 0;
        $street = trim(post_string('street'));

        $password = post_string('password');

        if (!isset($_POST['consent']) || $_POST['consent'] !== '1') {
            $error = 'Kailangan mong sumang-ayon sa Privacy Policy at Terms & Conditions para makagawa ng account.';
        } elseif (!isValidPhilippineMobileNumber($contactNo)) {
            $error = 'Maglagay ng kapani-paniwalang 11-digit mobile number na nagsisimula sa 09.';
        } elseif ($blk === 0 || $lot === 0) {
            $error = 'Maglagay ng wastong Block (1–100) at Lot (1–100).';
        } elseif ($street === '' || mb_strlen($street) > 50) {
            $error = 'Maglagay ng wastong Street (1 hanggang 50 character).';
        } elseif (!isValidNewPassword($password)) {
            $error = 'Ang password ay dapat 12 hanggang 64 character.';
        } elseif ($fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Punan nang tama ang lahat ng kinakailangang field.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // Formatted display para sa notification at block_lot column
            $blockLotDisplay = mb_substr("Blk {$blk} Lot {$lot}, {$street}", 0, 50);

            try {
                $conn->begin_transaction();

                if (usersHasAccountStatus($conn)) {
                    // Kailangang i-approve muna ng admin bago makapag-login.
                    $userStmt = $conn->prepare(
                        "INSERT INTO users (full_name, email, password, role, contact_no, account_status)
                         VALUES (?, ?, ?, 'resident', ?, 'pending')"
                    );
                } else {
                    $userStmt = $conn->prepare(
                        "INSERT INTO users (full_name, email, password, role, contact_no)
                         VALUES (?, ?, ?, 'resident', ?)"
                    );
                }
                $userStmt->bind_param('ssss', $fullName, $email, $hash, $contactNo);
                $userStmt->execute();
                $userId = $conn->insert_id;

                // INSERT ng hiwalay na blk at lot sa residents table kasama ang block_lot display
                $residentStmt = $conn->prepare(
                    'INSERT INTO residents (user_id, blk, lot, block_lot) VALUES (?, ?, ?, ?)'
                );
                $residentStmt->bind_param('iiis', $userId, $blk, $lot, $blockLotDisplay);
                $residentStmt->execute();

                $conn->commit();

                // Ipaalam sa admin/officer gamit ang formatted Block, Lot at Street display
                notifyStaff(
                    $conn,
                    'registration',
                    'Bagong rehistro',
                    $fullName . ' — ' . $blockLotDisplay . ' (naghihintay ng approval)',
                    'residents.php'
                );
                $registered = true;
            } catch (mysqli_sql_exception $exception) {
                $conn->rollback();
                if ($exception->getCode() === 1062) {
                    $error = 'May account na gamit ang email na ito.';
                } else {
                    error_log('Registration failed: ' . $exception->getMessage());
                    $error = 'Hindi nakumpleto ang registration. Subukan muli.';
                }
                $registered = false;
            }

            if ($registered) {
                header('Location: login.php?registered=pending');
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register | Adelina 3 Homeowners Association</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= (int) filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head>
<body class="auth-page">
  <main class="login-wrap">
    <section class="login-card">
      <a class="login-home-link" href="landing.php"><span aria-hidden="true">&larr;</span> Bumalik sa landing page</a>
      <h1>Adelina 3 Homeowners Association</h1>
      <p class="muted">Gumawa ng account</p>
      <?php if ($error !== ''): ?>
        <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
      <?php endif; ?>
      <form action="register.php" method="post">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
        <label for="fullName">Full Name</label>
        <input id="fullName" type="text" name="full_name" value="<?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>" placeholder="Juan Dela Cruz" autocomplete="name" required>
        <label for="registerEmail">Email</label>
        <input id="registerEmail" type="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" placeholder="sample123@gmail.com" autocomplete="email" required>
        <label for="registerPassword">Password (12-64 characters)</label>
        <div class="password-field">
          <input id="registerPassword" type="password" name="password" placeholder="Password" minlength="12" maxlength="64" autocomplete="new-password" required>
          <button type="button" class="password-toggle" data-password-toggle="registerPassword" aria-label="Ipakita ang password" aria-pressed="false">
            <svg class="eye-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          </button>
        </div>
        <label for="contactNo">Contact Number</label>
        <input id="contactNo" type="tel" name="contact_no" data-validate-ph-mobile value="<?= htmlspecialchars($contactNo, ENT_QUOTES, 'UTF-8') ?>" placeholder="09XXXXXXXXX" minlength="11" maxlength="11" pattern="09[0-9]{9}" inputmode="numeric" autocomplete="tel" title="Kapani-paniwalang 11 digit na numero na nagsisimula sa 09" required>

        <!-- Magkatabi sa isang halera at sakop ang buong lapad ng box -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; width: 100%;">
          <div>
            <label for="blk">Block</label>
            <input id="blk" type="number" name="blk" min="1" max="100" step="1" value="<?= htmlspecialchars((string) $blk, ENT_QUOTES, 'UTF-8') ?>" style="width: 100%;" required>
          </div>
          <div>
            <label for="lot">Lot</label>
            <input id="lot" type="number" name="lot" min="1" max="100" step="1" value="<?= htmlspecialchars((string) $lot, ENT_QUOTES, 'UTF-8') ?>" style="width: 100%;" required>
          </div>
        </div>

        <!-- Street field sa ibaba ng Block & Lot -->
        <label for="registerStreet">Street</label>
        <input id="registerStreet" type="text" name="street" maxlength="50" value="<?= htmlspecialchars($street, ENT_QUOTES, 'UTF-8') ?>" placeholder="Hal. Sampaguita St." required>

        <label class="consent-check">
          <input type="checkbox" name="consent" value="1" required>
          <span>Nabasa at sumasang-ayon ako sa <a href="privacy.php" target="_blank" rel="noopener">Privacy Policy</a> at <a href="terms.php" target="_blank" rel="noopener">Terms &amp; Conditions</a> ng Adelina 3 HOA.</span>
        </label>
        <button type="submit" class="btn btn-primary btn-block">Register</button>
      </form>
      <p class="muted">May account na? <a href="login.php">Mag-login</a></p>
    </section>
  </main>
  <script src="assets/js/script.js?v=<?= (int) filemtime(__DIR__ . '/assets/js/script.js') ?>"></script>
</body>
</html>