<?php
// Inaalis ang session data at session cookie, at ibinabalik ang user sa login page.
require_once 'includes/helpers.php';
start_secure_session();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();
header('Location: login.php');
exit;
?>
