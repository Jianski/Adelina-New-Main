<?php
// Pinamamahalaan ng page na ito ang pagsumite ng resident at pagproseso ng staff sa mga report.
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/validation.php';

$pageTitle = 'Complaints';
$role = $_SESSION['role'] ?? 'resident';
$isResident = $role === 'resident';
$isStaff = in_array($role, ['admin', 'officer'], true);
$isAdmin = $role === 'admin';
$userId = (int) $_SESSION['user_id'];
$actorName = trim((string) ($_SESSION['full_name'] ?? ''));
$error = '';
$message = $_SESSION['complaint_message'] ?? '';
$warning = $_SESSION['complaint_warning'] ?? '';
unset($_SESSION['complaint_message']);
unset($_SESSION['complaint_warning']);

// Mga pinapayagang pagpipilian at limitasyon para ma-validate ang input at attachment.
$csrfToken = csrf_token();
$categories = ['Noise', 'Parking', 'Garbage', 'Water', 'Security', 'Others'];
$reportTypes = ['Complaint', 'Suggestion'];
$statuses = ['Pending', 'In Progress', 'Resolved'];
$attachmentTypes = [
    'jpg' => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png' => ['image/png'],
    'gif' => ['image/gif'],
    'webp' => ['image/webp'],
    'pdf' => ['application/pdf'],
    'txt' => ['text/plain'],
    'doc' => ['application/msword', 'application/octet-stream'],
    'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
    'xls' => ['application/vnd.ms-excel', 'application/octet-stream'],
    'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'],
];
$maxAttachmentBytes = 10 * 1024 * 1024;
$category = '';
$reportType = 'Complaint';
$subject = '';
$otherSpecify = '';
$details = '';
$blockLot = '';

// Iniuugnay ang resident sa profile niya, kasama ang Block/Lot para sa form.
$residentId = 0;
if ($isResident) {
    $residentStmt = $conn->prepare('SELECT resident_id, block_lot FROM residents WHERE user_id = ? LIMIT 1');
    $residentStmt->bind_param('i', $userId);
    $residentStmt->execute();
    $resident = $residentStmt->get_result()->fetch_assoc();
    if ($resident) {
        $residentId = (int) $resident['resident_id'];
        $blockLot = $resident['block_lot'];
    }
}

// Pinoproseso rito ang resident submission o staff status update pagkatapos suriin ang CSRF token.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (isset($_POST['clear_complaints'])) {
        if (!$isAdmin) {
            http_response_code(403);
            $error = 'Admin lang ang maaaring magbura ng lahat ng complaint history.';
        } else {
            try {
                $conn->query('DELETE FROM complaints');
                logAudit($conn, $userId, 'clear_complaints', 'Binura ang lahat ng complaint history.');
                $_SESSION['complaint_message'] = 'Nabura na ang lahat ng complaint history.';
                header('Location: complaints.php');
                exit;
            } catch (mysqli_sql_exception $exception) {
                error_log('Clear complaints failed: ' . $exception->getMessage());
                $error = 'Hindi nabura ang complaint history. Subukan muli.';
            }
        }
    } elseif (isset($_POST['file_complaint']) && $isResident) {
        $reportType = trim(post_string('report_type'));
        $category = trim(post_string('category'));
        $subject = trim(post_string('subject'));
        $otherSpecify = trim(post_string('other_specify'));
        $details = trim(post_string('details'));
        if ($category !== 'Others') {
            $otherSpecify = '';
        }
        $blockLot = $residentId > 0 ? $blockLot : trim(post_string('block_lot'));
        $attachment = $_FILES['attachment'] ?? null;
        $attachmentError = '';
        $attachmentExtension = '';
        $attachmentName = '';
        $invalidBlockLot = $residentId < 1 && !isValidBlockLot($blockLot);

        // Sinusuri ang laki, extension at aktuwal na MIME type bago tanggapin ang uploaded file.
        if ($attachment && $attachment['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($attachment['error'] !== UPLOAD_ERR_OK) {
                $attachmentError = $attachment['error'] === UPLOAD_ERR_INI_SIZE
                    || $attachment['error'] === UPLOAD_ERR_FORM_SIZE
                    ? 'Lumampas sa pinapayagang file size ang attachment.'
                    : 'Hindi na-upload ang attachment. Subukan muli.';
            } elseif ($attachment['size'] > $maxAttachmentBytes || !is_uploaded_file($attachment['tmp_name'])) {
                $attachmentError = 'Hanggang 10 MB lang ang attachment.';
            } else {
                $attachmentName = basename(str_replace('\\', '/', $attachment['name']));
                $attachmentName = preg_replace('/[\x00-\x1F\x7F]/u', '', $attachmentName) ?? '';
                $attachmentExtension = strtolower(pathinfo($attachmentName, PATHINFO_EXTENSION));
                $fileInfo = new finfo(FILEINFO_MIME_TYPE);
                $detectedMime = $fileInfo->file($attachment['tmp_name']);

                if (
                    $attachmentName === ''
                    || strlen($attachmentName) > 255
                    || !isset($attachmentTypes[$attachmentExtension])
                    || !in_array($detectedMime, $attachmentTypes[$attachmentExtension], true)
                ) {
                    $attachmentError = 'Hindi suportadong file. Mag-upload ng larawan, PDF, Word, Excel, o TXT file.';
                }
            }
        }

        if (
            !in_array($reportType, $reportTypes, true)
            || !in_array($category, $categories, true)
            || $subject === ''
            || mb_strlen($subject) > 150
            || ($category === 'Others' && ($otherSpecify === '' || mb_strlen($otherSpecify) > 100))
            || $details === ''
            || $invalidBlockLot
            || mb_strlen($blockLot) > 50
            || $attachmentError !== ''
        ) {
            $error = $attachmentError !== ''
                ? $attachmentError
                : ($invalidBlockLot
                    ? 'Maglagay ng wastong Block/Lot. Iwasan ang puro magkakapareho o sunod-sunod na numero.'
                    : 'Punan nang tama ang category, subject, specify kung Others, details, at Block/Lot kung hinihingi.');
        } else {
            // Magkasamang sine-save ang report at attachment upang maiwasan ang hindi kumpletong record.
            $storedAttachmentFile = null;
            $attachmentData = null;
            $attachmentMime = null;
            $conn->begin_transaction();

            try {
                if ($residentId < 1) {
                    $profileStmt = $conn->prepare('INSERT INTO residents (user_id, block_lot) VALUES (?, ?)');
                    $profileStmt->bind_param('is', $userId, $blockLot);
                    $profileStmt->execute();
                    $residentId = (int) $conn->insert_id;
                }

                if ($attachment && $attachment['error'] === UPLOAD_ERR_OK) {
                    // Naka-save na sa database ang attachment, hindi na sa folder,
                    // para hindi na kailangan ng folder permission sa hosting.
                    $storedAttachmentFile = bin2hex(random_bytes(16)) . '.' . $attachmentExtension;
                    $attachmentData = file_get_contents($attachment['tmp_name']);
                    $attachmentMime = $detectedMime;
                    if ($attachmentData === false) {
                        $storedAttachmentFile = null;
                        $attachmentData = null;
                        $attachmentMime = null;
                        throw new RuntimeException('Hindi na-save ang attachment.');
                    }
                }

                $stmt = $conn->prepare(
                    "INSERT INTO complaints (resident_id, report_type, category, other_specify, subject, details, status, attachment_file, attachment_name, attachment_data, attachment_mime)
                     VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, ?)"
                );
                $stmt->bind_param('isssssssss', $residentId, $reportType, $category, $otherSpecify, $subject, $details, $storedAttachmentFile, $attachmentName, $attachmentData, $attachmentMime);
                $stmt->execute();
                $conn->commit();

                // Ipaalam sa admin/officer na may bagong reklamo o suggestion ang resident.
                notifyStaff(
                    $conn,
                    'complaint',
                    'Bagong reklamo',
                    ($actorName !== '' ? $actorName . ': ' : '') . $subject,
                    'complaints.php'
                );

                $_SESSION['complaint_message'] = $reportType === 'Suggestion'
                    ? 'Matagumpay na naipasa ang suggestion.'
                    : 'Matagumpay na naipasa ang complaint.';
                header('Location: complaints.php');
                exit;
            } catch (mysqli_sql_exception $exception) {
                $conn->rollback();
                error_log('Complaint submission failed: ' . $exception->getMessage());
                $error = 'Hindi naipasa ang complaint. Subukan muli.';
            } catch (RuntimeException $exception) {
                $conn->rollback();
                error_log('Complaint attachment failed: ' . $exception->getMessage());
                $error = 'Hindi na-save ang attachment. Suriin ang folder permission at subukan muli.';
            }
        }
    } elseif (isset($_POST['delete_complaint'])) {
        if (!$isAdmin) {
            http_response_code(403);
            $error = 'Admin lang ang maaaring magtanggal ng complaint history.';
        } else {
            $complaintId = filter_var(
                $_POST['complaint_id'] ?? null,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1]]
            );

            if ($complaintId === false) {
                $error = 'Hindi wasto ang complaint history na pinili.';
            } else {
                $transactionStarted = false;
                try {
                    $conn->begin_transaction();
                    $transactionStarted = true;

                    $attachmentStmt = $conn->prepare(
                        'SELECT attachment_file FROM complaints WHERE complaint_id = ? FOR UPDATE'
                    );
                    $attachmentStmt->bind_param('i', $complaintId);
                    $attachmentStmt->execute();
                    $complaint = $attachmentStmt->get_result()->fetch_assoc();

                    if (!$complaint) {
                        $conn->rollback();
                        $transactionStarted = false;
                        $error = 'Hindi makita ang complaint history na tatanggalin.';
                    } else {
                        $deleteStmt = $conn->prepare('DELETE FROM complaints WHERE complaint_id = ?');
                        $deleteStmt->bind_param('i', $complaintId);
                        $deleteStmt->execute();
                        $conn->commit();
                        $transactionStarted = false;
                        logAudit($conn, $userId, 'delete_complaint', 'Binura ang complaint (complaint_id=' . $complaintId . ').');

                        $attachmentCleanupFailed = false;
                        $attachmentFile = $complaint['attachment_file'] ?? '';
                        if ($attachmentFile !== '') {
                            if (!preg_match('/^[a-f0-9]{32}\.(?:jpg|jpeg|png|gif|webp|pdf|txt|doc|docx|xls|xlsx)$/i', $attachmentFile)) {
                                $attachmentCleanupFailed = true;
                                error_log('Complaint removal found an invalid attachment filename.');
                            } else {
                                $attachmentPath = dirname(__DIR__, 2)
                                    . DIRECTORY_SEPARATOR . 'hoa-complaint-attachments'
                                    . DIRECTORY_SEPARATOR . $attachmentFile;
                                if (is_file($attachmentPath) && !unlink($attachmentPath)) {
                                    $attachmentCleanupFailed = true;
                                    error_log('Complaint removal could not delete its attachment file.');
                                }
                            }
                        }

                        if ($attachmentCleanupFailed) {
                            $_SESSION['complaint_warning'] = 'Nabura ang complaint history, pero hindi naalis ang attachment file. Ipa-check ito sa admin.';
                        } else {
                            $_SESSION['complaint_message'] = 'Matagumpay na nabura ang complaint history.';
                        }
                        header('Location: complaints.php');
                        exit;
                    }
                } catch (mysqli_sql_exception $exception) {
                    if ($transactionStarted) {
                        $conn->rollback();
                    }
                    error_log('Complaint removal failed: ' . $exception->getMessage());
                    $error = 'Hindi natanggal ang complaint history. Subukan muli.';
                }
            }
        }
    } elseif (isset($_POST['update_complaint']) && $isStaff) {
        $complaintId = filter_var(
            $_POST['complaint_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );
        $status = trim(post_string('status'));
        $officerResponse = trim(post_string('officer_response'));

        if ($complaintId === false || !in_array($status, $statuses, true)) {
            $error = 'Hindi wasto ang complaint o status na pinili.';
        } else {
            // Kinukuha ang detalye ng complaint para sa notification sa resident.
            $complaintInfo = null;
            $complaintInfoStmt = $conn->prepare(
                'SELECT c.subject, r.user_id
                 FROM complaints c
                 JOIN residents r ON c.resident_id = r.resident_id
                 WHERE c.complaint_id = ?'
            );
            $complaintInfoStmt->bind_param('i', $complaintId);
            $complaintInfoStmt->execute();
            $complaintInfo = $complaintInfoStmt->get_result()->fetch_assoc();

            $stmt = $conn->prepare(
                'UPDATE complaints SET status = ?, officer_response = ? WHERE complaint_id = ?'
            );
            $stmt->bind_param('ssi', $status, $officerResponse, $complaintId);
            $stmt->execute();

            if ($stmt->affected_rows > 0 && $complaintInfo) {
                $complaintSubject = trim((string) ($complaintInfo['subject'] ?? ''));
                $complaintMessage = 'Ang complaint mo' . ($complaintSubject !== '' ? ' na "' . $complaintSubject . '"' : '') . ' ay ' . $status . ' na.';
                if ($officerResponse !== '') {
                    $complaintMessage .= ' Sagot ng officer: ' . $officerResponse;
                }
                notifyUser(
                    $conn,
                    (int) $complaintInfo['user_id'],
                    'complaint',
                    'May update sa complaint mo',
                    $complaintMessage,
                    'complaints.php'
                );
            }

            $_SESSION['complaint_message'] = $stmt->affected_rows > 0
                ? 'Matagumpay na na-update ang complaint.'
                : 'Walang nabagong detalye o hindi makita ang complaint.';
            header('Location: complaints.php');
            exit;
        }
    } else {
        http_response_code(403);
        $error = 'Walang pahintulot para sa complaint action na ito.';
    }
}

// Staff lang ang nakakakita ng lahat; ang resident ay nakakakita lamang ng sariling report.
$complaintPageSize = 10;
$complaintPage = paginationPage();
$complaintSearch = isset($_GET['q']) && is_string($_GET['q']) ? trim($_GET['q']) : '';
$complaintSearchPattern = '%' . $complaintSearch . '%';
$complaintPaginationParams = $complaintSearch === '' ? [] : ['q' => $complaintSearch];
$complaintSearchSql = $complaintSearch === ''
    ? ''
    : "CONCAT_WS(' ', c.report_type, c.category, c.other_specify, c.subject, c.details,
                 c.status, c.officer_response, c.attachment_name, u.full_name, r.block_lot) LIKE ?";
$complaintSelect = 'SELECT c.complaint_id, c.report_type, c.category, c.other_specify, c.subject, c.details, c.status,
                           c.attachment_file, c.attachment_name, c.officer_response, c.date_filed,
                           u.full_name, r.block_lot
                    FROM complaints c
                    JOIN residents r ON c.resident_id = r.resident_id
                    JOIN users u ON r.user_id = u.user_id';

if ($isStaff) {
    $complaintCountStmt = $conn->prepare(
        'SELECT COUNT(*) AS total
         FROM complaints c
         JOIN residents r ON c.resident_id = r.resident_id
         JOIN users u ON r.user_id = u.user_id'
         . ($complaintSearch === '' ? '' : ' WHERE ' . $complaintSearchSql)
    );
    if ($complaintSearch !== '') {
        $complaintCountStmt->bind_param('s', $complaintSearchPattern);
    }
    $complaintCountStmt->execute();
    $complaintCount = (int) $complaintCountStmt->get_result()->fetch_assoc()['total'];
    $complaintTotalPages = max(1, (int) ceil($complaintCount / $complaintPageSize));
    $complaintPage = min($complaintPage, $complaintTotalPages);
    $complaintOffset = ($complaintPage - 1) * $complaintPageSize;
    $complaintStmt = $conn->prepare(
        $complaintSelect . ($complaintSearch === '' ? '' : ' WHERE ' . $complaintSearchSql)
        . ' ORDER BY c.date_filed DESC, c.complaint_id DESC'
        . ' LIMIT ' . $complaintPageSize . ' OFFSET ' . $complaintOffset
    );
    if ($complaintSearch !== '') {
        $complaintStmt->bind_param('s', $complaintSearchPattern);
    }
    $complaintStmt->execute();
    $complaints = $complaintStmt->get_result();
} elseif ($isResident) {
    if ($residentId > 0) {
        $complaintCountStmt = $conn->prepare(
            'SELECT COUNT(*) AS total FROM complaints WHERE resident_id = ?'
            . ($complaintSearch === '' ? '' : ' AND ' . $complaintSearchSql)
        );
        if ($complaintSearch === '') {
            $complaintCountStmt->bind_param('i', $residentId);
        } else {
            $complaintCountStmt->bind_param('is', $residentId, $complaintSearchPattern);
        }
        $complaintCountStmt->execute();
        $complaintCount = (int) $complaintCountStmt->get_result()->fetch_assoc()['total'];
        $complaintTotalPages = max(1, (int) ceil($complaintCount / $complaintPageSize));
        $complaintPage = min($complaintPage, $complaintTotalPages);
        $complaintOffset = ($complaintPage - 1) * $complaintPageSize;
        $complaintStmt = $conn->prepare(
            $complaintSelect . ' WHERE c.resident_id = ?'
            . ($complaintSearch === '' ? '' : ' AND ' . $complaintSearchSql)
            . ' ORDER BY c.date_filed DESC, c.complaint_id DESC'
            . ' LIMIT ' . $complaintPageSize . ' OFFSET ' . $complaintOffset
        );
        if ($complaintSearch === '') {
            $complaintStmt->bind_param('i', $residentId);
        } else {
            $complaintStmt->bind_param('is', $residentId, $complaintSearchPattern);
        }
        $complaintStmt->execute();
        $complaints = $complaintStmt->get_result();
    } else {
        $complaints = $conn->query($complaintSelect . ' WHERE 1 = 0');
        $complaintTotalPages = 1;
    }
}

require_once 'includes/header.php';
?>
<div class="page-header"><h2>Complaints</h2></div>
<?php if ($error !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($message !== ''): ?>
  <p class="alert alert-success" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($warning !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($warning, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<?php if ($isResident): ?>
  <section class="card">
    <h3>File Complaint / Report</h3>
    <?php if ($residentId < 1): ?>
      <p class="muted">Ilagay ang Block/Lot para ma-link ang unang complaint sa resident profile mo.</p>
    <?php endif; ?>
      <form class="form-grid" action="complaints.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
        <?php if ($residentId < 1): ?>
          <div class="form-field form-field-wide">
            <label for="complaintBlockLot">Block/Lot</label>
            <input id="complaintBlockLot" type="text" name="block_lot" data-validate-block-lot maxlength="50" value="<?= htmlspecialchars($blockLot, ENT_QUOTES, 'UTF-8') ?>" placeholder="Hal. Block 1 Lot 5" required>
          </div>
        <?php endif; ?>
        <div class="form-field">
          <label for="reportType">Type</label>
          <select id="reportType" name="report_type" required>
            <?php foreach ($reportTypes as $option): ?>
              <option value="<?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?>"<?= $reportType === $option ? ' selected' : '' ?>><?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field">
          <label for="complaintCategory">Category</label>
          <select id="complaintCategory" name="category" required>
            <option value="">-- Piliin ang category --</option>
            <?php foreach ($categories as $option): ?>
              <option value="<?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?>"<?= $category === $option ? ' selected' : '' ?>><?= htmlspecialchars($option, ENT_QUOTES, 'UTF-8') ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field">
          <label for="complaintSubject">Subject/Address</label>
          <input id="complaintSubject" type="text" name="subject" value="<?= htmlspecialchars($subject, ENT_QUOTES, 'UTF-8') ?>" maxlength="150" placeholder="Paksa o address ng concern" required>
        </div>
        <div class="form-field" id="otherSpecifyWrap"<?= $category === 'Others' ? '' : ' hidden' ?>>
          <label for="otherSpecifyInput">Specify</label>
          <input id="otherSpecifyInput" type="text" name="other_specify" value="<?= htmlspecialchars($otherSpecify, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" placeholder="Ilagay ang ibang category"<?= $category === 'Others' ? ' required' : '' ?>>
        </div>
        <div class="form-field form-field-wide">
          <label for="complaintDetails">Details</label>
          <textarea id="complaintDetails" name="details" rows="4" placeholder="Ilarawan ang concern..." required><?= htmlspecialchars($details, ENT_QUOTES, 'UTF-8') ?></textarea>
        </div>
        <div class="form-field form-field-wide">
          <label for="complaintAttachment">Attachment (optional)</label>
          <input id="complaintAttachment" type="file" name="attachment" accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.doc,.docx,.xls,.xlsx,.txt">
          <small class="muted">Larawan, PDF, Word, Excel, o TXT; hanggang 10 MB.</small>
          <div class="image-editor" data-image-editor data-image-input="complaintAttachment" data-max-output-size="10485760" hidden>
            <strong>Image preview at adjustment</strong>
            <div class="image-editor-preview"><canvas data-image-canvas aria-label="Preview ng edited complaint image"></canvas></div>
            <div class="image-editor-controls">
              <label>Crop
                <select data-image-crop>
                  <option value="free">Buong image</option>
                  <option value="1:1">Square (1:1)</option>
                  <option value="4:3">Landscape (4:3)</option>
                  <option value="16:9">Wide (16:9)</option>
                </select>
              </label>
              <label>Liwanag
                <input data-image-brightness type="range" min="50" max="150" value="100">
              </label>
              <label>Contrast
                <input data-image-contrast type="range" min="50" max="150" value="100">
              </label>
            </div>
            <div class="image-editor-actions">
              <button type="button" class="btn btn-small" data-image-rotate="-90">I-rotate pakaliwa</button>
              <button type="button" class="btn btn-small" data-image-rotate="90">I-rotate pakanan</button>
              <button type="button" class="btn btn-small" data-image-reset>I-reset</button>
            </div>
            <small class="muted" data-image-status aria-live="polite">Hindi babaguhin ang upload hangga't hindi ina-adjust.</small>
          </div>
        </div>
        <div class="form-actions"><button type="submit" name="file_complaint" value="1" class="btn btn-primary">Submit Complaint</button></div>
      </form>
  </section>
<?php endif; ?>

<?php if ($isStaff || $isResident): ?>
  <section class="card complaint-list">
    <div class="card-head">
      <h3><?= $isStaff ? 'All Complaints' : 'My Complaints' ?></h3>
      <?php if ($isAdmin): ?>
        <form action="complaints.php" method="post" onsubmit="return confirm('Buburahin ang LAHAT ng complaint history. Sigurado ka?');">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <button type="submit" name="clear_complaints" value="1" class="btn btn-danger btn-small">Burahin ang Lahat ng History</button>
        </form>
      <?php endif; ?>
      <form action="complaints.php" method="get" class="pagination-search">
        <input type="search" id="searchInput" name="q" value="<?= htmlspecialchars($complaintSearch, ENT_QUOTES, 'UTF-8') ?>" placeholder="Mag-search ng complaint..." aria-label="Search complaints">
        <button type="submit" class="btn btn-small">Search</button>
      </form>
    </div>
    <div class="table-wrap">
      <table class="table" id="dataTable">
        <thead><tr><th>Resident</th><th>Block/Lot</th><th>Type</th><th>Category</th><th>Subject/Address</th><th>Details</th><th>Date Filed</th><th>Status</th><?php if ($isStaff): ?><th>Officer Response / Update</th><?php else: ?><th>Officer Response</th><?php endif; ?><?php if ($isAdmin): ?><th>Action</th><?php endif; ?></tr></thead>
        <tbody>
          <?php if ($complaints->num_rows === 0): ?>
            <tr><td colspan="<?= $isAdmin ? 10 : 9 ?>">Wala pang complaints o suggestions.</td></tr>
          <?php else: ?>
            <?php while ($complaint = $complaints->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($complaint['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($complaint['block_lot'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($complaint['report_type'] ?? 'Complaint', ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                  <?= htmlspecialchars($complaint['category'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                  <?php if (($complaint['category'] ?? '') === 'Others' && !empty($complaint['other_specify'])): ?>
                    <div class="muted">Specify: <?= htmlspecialchars($complaint['other_specify'], ENT_QUOTES, 'UTF-8') ?></div>
                  <?php endif; ?>
                </td>
                <td>
                  <strong><?= htmlspecialchars($complaint['subject'], ENT_QUOTES, 'UTF-8') ?></strong>
                </td>
                <td>
                  <?= nl2br(htmlspecialchars($complaint['details'] ?? '', ENT_QUOTES, 'UTF-8')) ?>
                  <?php if (!empty($complaint['attachment_name'])): ?>
                    <a href="download_complaint_attachment.php?id=<?= (int) $complaint['complaint_id'] ?>">Attachment: <?= htmlspecialchars($complaint['attachment_name'], ENT_QUOTES, 'UTF-8') ?></a>
                    <?php if (
                        $isStaff
                        && preg_match('/\A[a-f0-9]{32}\.(?:jpg|jpeg|png|gif|webp)\z/i', (string) ($complaint['attachment_file'] ?? ''))
                    ): ?>
                      <button
                        type="button"
                        class="complaint-image-hold"
                        data-hold-image-preview
                        aria-label="Pindutin nang matagal para palakihin ang larawan"
                      >
                        <img
                          class="complaint-image-preview"
                          src="download_complaint_attachment.php?id=<?= (int) $complaint['complaint_id'] ?>&amp;preview=1"
                          alt="<?= htmlspecialchars($complaint['attachment_name'] ?? 'Attachment ng complaint', ENT_QUOTES, 'UTF-8') ?>"
                          loading="lazy"
                        >
                      </button>
                    <?php endif; ?>
                  <?php endif; ?>
                </td>
                <td><?= $complaint['date_filed'] ? htmlspecialchars(date('M d, Y', strtotime($complaint['date_filed'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                <td><span class="badge <?= $complaint['status'] === 'Pending' ? 'badge-pending' : ($complaint['status'] === 'In Progress' ? 'badge-progress' : 'badge-paid') ?>"><?= htmlspecialchars($complaint['status'] ?? 'Pending', ENT_QUOTES, 'UTF-8') ?></span></td>
                <td>
                  <?php if ($isStaff): ?>
                    <form action="complaints.php" method="post" class="complaint-update-form">
                      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                      <input type="hidden" name="complaint_id" value="<?= (int) $complaint['complaint_id'] ?>">
                      <label class="visually-hidden" for="status-<?= (int) $complaint['complaint_id'] ?>">Status</label>
                      <select id="status-<?= (int) $complaint['complaint_id'] ?>" name="status" required>
                        <?php foreach ($statuses as $statusOption): ?>
                          <option value="<?= htmlspecialchars($statusOption, ENT_QUOTES, 'UTF-8') ?>"<?= $complaint['status'] === $statusOption ? ' selected' : '' ?>><?= htmlspecialchars($statusOption, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                      </select>
                      <label class="visually-hidden" for="response-<?= (int) $complaint['complaint_id'] ?>">Officer Response</label>
                      <textarea id="response-<?= (int) $complaint['complaint_id'] ?>" name="officer_response" rows="2" placeholder="Officer response..."><?= htmlspecialchars($complaint['officer_response'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                      <button type="submit" name="update_complaint" value="1" class="btn btn-small">Update</button>
                    </form>
                  <?php else: ?>
                    <?= nl2br(htmlspecialchars($complaint['officer_response'] ?? '', ENT_QUOTES, 'UTF-8')) ?>
                  <?php endif; ?>
                </td>
                <?php if ($isAdmin): ?>
                  <td>
                    <form action="complaints.php" method="post" class="confirm-form" data-confirm="Permanenteng buburahin ang complaint history at attachment nito. Hindi na ito maibabalik. Magpatuloy?">
                      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                      <input type="hidden" name="complaint_id" value="<?= (int) $complaint['complaint_id'] ?>">
                      <button type="submit" name="delete_complaint" value="1" class="btn btn-danger btn-small">Delete History</button>
                    </form>
                  </td>
                <?php endif; ?>
              </tr>
            <?php endwhile; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php renderPagination($complaintPage, $complaintTotalPages, $complaintPaginationParams); ?>
  </section>
<?php endif; ?>
<div class="complaint-image-lightbox" data-complaint-image-lightbox hidden role="dialog" aria-modal="true" aria-label="Pinalaking larawan ng complaint">
  <button type="button" class="complaint-image-lightbox-close" data-complaint-image-close aria-label="Isara ang larawan">&times;</button>
  <img data-complaint-image-large alt="Pinalaking larawan ng complaint">
</div>
<?php require_once 'includes/footer.php'; ?>