<?php
// Ipinapakita rito ang magkakaibang buod para sa staff at sa naka-login na resident.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Dashboard';
$role = strtolower($_SESSION['role'] ?? 'resident');
$isStaff = in_array($role, ['admin', 'officer'], true);
$userId = (int) $_SESSION['user_id'];
$residentId = 0;

// Hinahanap ang resident record upang ma-filter sa sariling account ang mga bilang.
if (!$isStaff) {
    $residentStmt = $conn->prepare('SELECT resident_id FROM residents WHERE user_id = ? LIMIT 1');
    $residentStmt->bind_param('i', $userId);
    $residentStmt->execute();
    $resident = $residentStmt->get_result()->fetch_assoc();
    if ($resident) {
        $residentId = (int) $resident['resident_id'];
    }
}

// Kinukuha ang angkop na mga bilang depende sa role.
if ($isStaff) {
    $stats = [
        ['Total Residents', (int) $conn->query("SELECT COUNT(*) AS c FROM residents WHERE status = 'active'")->fetch_assoc()['c']],
        ['Unpaid Dues', (int) $conn->query("SELECT COUNT(*) AS c FROM payments WHERE status = 'Unpaid'")->fetch_assoc()['c']],
        ['Open Complaints', (int) $conn->query("SELECT COUNT(*) AS c FROM complaints WHERE status != 'Resolved'")->fetch_assoc()['c']],
        ['Reservations', (int) $conn->query('SELECT COUNT(*) AS c FROM reservations')->fetch_assoc()['c']],
    ];
} else {
    $stats = [
        ['My Unpaid Dues', 0],
        ['My Open Complaints', 0],
        ['My Reservations', 0],
        ['Announcements', (int) $conn->query('SELECT COUNT(*) AS c FROM announcements')->fetch_assoc()['c']],
    ];

    if ($residentId > 0) {
        $unpaidStmt = $conn->prepare("SELECT COUNT(*) AS c FROM payments WHERE resident_id = ? AND status = 'Unpaid'");
        $unpaidStmt->bind_param('i', $residentId);
        $unpaidStmt->execute();
        $stats[0][1] = (int) $unpaidStmt->get_result()->fetch_assoc()['c'];

        $complaintsStmt = $conn->prepare("SELECT COUNT(*) AS c FROM complaints WHERE resident_id = ? AND status != 'Resolved'");
        $complaintsStmt->bind_param('i', $residentId);
        $complaintsStmt->execute();
        $stats[1][1] = (int) $complaintsStmt->get_result()->fetch_assoc()['c'];

        $reservationsStmt = $conn->prepare('SELECT COUNT(*) AS c FROM reservations WHERE resident_id = ?');
        $reservationsStmt->bind_param('i', $residentId);
        $reservationsStmt->execute();
        $stats[2][1] = (int) $reservationsStmt->get_result()->fetch_assoc()['c'];
    }
}

// Pareho ang announcement list na ipinapakita sa staff at resident dashboard.
$latestAnnouncements = $conn->query(
    'SELECT title, body, date_posted FROM announcements ORDER BY date_posted DESC, announcement_id DESC LIMIT 3'
);
$announcementRows = [];
while ($announcement = $latestAnnouncements->fetch_assoc()) {
    $announcementRows[] = $announcement;
}

// Kinukuha ang datos para sa mga chart sa dashboard.
// Staff: lahat ng bayad at reklamo. Resident: sariling bayad at reklamo lang.
$buwanPangalan = [
    '01' => 'Enero', '02' => 'Pebrero', '03' => 'Marso', '04' => 'Abril',
    '05' => 'Mayo', '06' => 'Hunyo', '07' => 'Hulyo', '08' => 'Agosto',
    '09' => 'Setyembre', '10' => 'Oktubre', '11' => 'Nobyembre', '12' => 'Disyembre',
];

// Kasaysayan ng bayad: kabuuang Paid bawat buwan, huling 6 na buwan.
$paymentChartSql = "SELECT DATE_FORMAT(date_paid, '%Y-%m') AS buwan, SUM(amount) AS kabuuan "
    . 'FROM payments WHERE status = \'Paid\' AND date_paid IS NOT NULL';
if (!$isStaff) {
    $paymentChartSql .= ' AND resident_id = ?';
}
$paymentChartSql .= ' GROUP BY buwan ORDER BY buwan DESC LIMIT 6';
if ($isStaff) {
    $paymentChartResult = $conn->query($paymentChartSql);
} else {
    $paymentChartStmt = $conn->prepare($paymentChartSql);
    $paymentChartStmt->bind_param('i', $residentId);
    $paymentChartStmt->execute();
    $paymentChartResult = $paymentChartStmt->get_result();
}
$paymentChartRows = [];
$paymentChartMax = 0.0;
while ($paymentChartRow = $paymentChartResult->fetch_assoc()) {
    $kabuuan = (float) $paymentChartRow['kabuuan'];
    [$taon, $buwan] = explode('-', (string) $paymentChartRow['buwan']);
    $paymentChartRows[] = [
        'label' => ($buwanPangalan[$buwan] ?? $buwan) . ' ' . $taon,
        'kabuuan' => $kabuuan,
        'pct' => 0.0,
    ];
    if ($kabuuan > $paymentChartMax) {
        $paymentChartMax = $kabuuan;
    }
}
$paymentChartRows = array_reverse($paymentChartRows);
foreach ($paymentChartRows as &$paymentChartRow) {
    $paymentChartRow['pct'] = $paymentChartMax > 0 ? ($paymentChartRow['kabuuan'] / $paymentChartMax) * 100 : 0;
}
unset($paymentChartRow);

// Katayuan ng mga reklamo: bilang bawat status (Pending / In Progress / Resolved).
$complaintChartSql = 'SELECT status, COUNT(*) AS bilang FROM complaints';
if (!$isStaff) {
    $complaintChartSql .= ' WHERE resident_id = ?';
}
$complaintChartSql .= ' GROUP BY status';
if ($isStaff) {
    $complaintChartResult = $conn->query($complaintChartSql);
} else {
    $complaintChartStmt = $conn->prepare($complaintChartSql);
    $complaintChartStmt->bind_param('i', $residentId);
    $complaintChartStmt->execute();
    $complaintChartResult = $complaintChartStmt->get_result();
}
$complaintChartBilang = ['Pending' => 0, 'In Progress' => 0, 'Resolved' => 0];
while ($complaintChartRow = $complaintChartResult->fetch_assoc()) {
    $statusKey = (string) ($complaintChartRow['status'] ?? '');
    if (array_key_exists($statusKey, $complaintChartBilang)) {
        $complaintChartBilang[$statusKey] = (int) $complaintChartRow['bilang'];
    }
}
$complaintChartTotal = array_sum($complaintChartBilang);
$complaintChartRows = [
    ['label' => 'Naghihintay', 'class' => 'chart-fill-pending', 'bilang' => $complaintChartBilang['Pending']],
    ['label' => 'Ginagawa', 'class' => 'chart-fill-progress', 'bilang' => $complaintChartBilang['In Progress']],
    ['label' => 'Nalutas', 'class' => 'chart-fill-resolved', 'bilang' => $complaintChartBilang['Resolved']],
];
foreach ($complaintChartRows as &$complaintChartRow) {
    $complaintChartRow['pct'] = $complaintChartTotal > 0 ? ($complaintChartRow['bilang'] / $complaintChartTotal) * 100 : 0;
}
unset($complaintChartRow);

// Ipinapasa ang nakalkulang datos sa iisang shared page layout.
require_once 'includes/header.php';
?>
<?php if (!$isStaff): ?>
  <section class="resident-home-hero">
    <div>
      <p>Resident Homepage</p>
      <h2>Maligayang pagdating, <?= htmlspecialchars(trim((string) ($_SESSION['full_name'] ?? 'Resident')), ENT_QUOTES, 'UTF-8') ?>!</h2>
      <span>Malayang tingnan ang iyong account at mga serbisyo ng HOA.</span>
    </div>
  </section>

  <div class="row g-3 mt-1 dashboard-stats">
    <?php
    $resIcons = [
        '<i class="bi bi-cash-coin"></i>',
        '<i class="bi bi-exclamation-circle-fill"></i>',
        '<i class="bi bi-calendar-check-fill"></i>',
        '<i class="bi bi-megaphone-fill"></i>'
    ];
    $resLinks = ['payments.php', 'complaints.php', 'reservations.php', 'announcements.php'];
    $resSubtitles = ['Pending balance', 'Active concerns', 'Booked facilities', 'Community updates'];
    $resThemes = [
        ['bg' => '#fef3c7', 'color' => '#b45309', 'border' => '#d97706'],
        ['bg' => '#fee2e2', 'color' => '#b91c1c', 'border' => '#dc2626'],
        ['bg' => '#e0f2fe', 'color' => '#0369a1', 'border' => '#0284c7'],
        ['bg' => '#e5f5ed', 'color' => '#087b4b', 'border' => '#087b4b'],
    ];

    foreach ($stats as $index => [$label, $value]):
        $theme = $resThemes[$index] ?? $resThemes[0];
    ?>
      <div class="col-12 col-sm-6 col-xl-3">
        <a href="<?= $resLinks[$index] ?? '#' ?>" class="text-decoration-none">
          <div class="card shadow-sm border-0 rounded-4 dashboard-stat-card h-100" style="border-left: 4px solid <?= $theme['border'] ?> !important;">
            <div class="card-body d-flex align-items-center justify-content-between">
              <div class="stat-info">
                <p class="text-muted mb-1 fw-medium"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></p>
                <h2 class="fw-bold mb-1" style="color: #123b30;"><?= htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8') ?></h2>
                <small class="text-secondary" style="font-size: 12px;"><?= $resSubtitles[$index] ?? '' ?></small>
              </div>
              <div class="stat-icon" style="background: <?= $theme['bg'] ?>; color: <?= $theme['color'] ?>;">
                <?= $resIcons[$index] ?? '<i class="bi bi-bar-chart-fill"></i>' ?>
              </div>
            </div>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>


  <section class="mt-4" aria-label="Mga chart">
    <div class="d-flex align-items-center gap-2 mb-3">
      <i class="bi bi-bar-chart-fill" style="color: #087b4b; font-size: 20px;"></i>
      <h4 class="fw-bold mb-0" style="color: #123b30;">Mga Chart</h4>
    </div>

    <div class="row g-3">
      <!-- Left Card: Kasaysayan ng Bayad -->
      <div class="col-12 col-lg-6">
        <div class="card shadow-sm border-0 rounded-4 h-100">
          <div class="card-body p-4 d-flex flex-column">
            <div class="d-flex align-items-center gap-3 mb-3">
              <div class="stat-icon" style="width: 44px; height: 44px; font-size: 20px;">
                <i class="bi bi-wallet-fill"></i>
              </div>
              <div>
                <h5 class="fw-bold mb-0" style="color: #123b30;">Kasaysayan ng Bayad</h5>
                <small class="text-muted">Kabuuang bayad bawat buwan (huling 6 na buwan)</small>
              </div>
            </div>

            <?php if (count($paymentChartRows) === 0): ?>
              <div class="my-auto text-center py-4">
                <div class="position-relative d-inline-block mb-3" style="color: #b7d7c8;">
                  <i class="bi bi-bar-chart-fill" style="font-size: 64px; opacity: 0.75;"></i>
                  <i class="bi bi-search position-absolute" style="font-size: 26px; color: #5c9e82; bottom: 4px; right: -10px;"></i>
                </div>
                <h6 class="fw-bold mb-1" style="color: #123b30;">Wala pang datos ng bayad.</h6>
                <p class="text-muted small mb-0 mx-auto" style="max-width: 280px;">
                  Ang iyong kasaysayan ng bayad ay lalabas dito kapag may naitalang transaksyon.
                </p>
              </div>
            <?php else: ?>
              <div class="d-flex flex-column gap-3 my-auto">
                <?php foreach ($paymentChartRows as $paymentRow): ?>
                  <div>
                    <div class="d-flex justify-content-between small fw-semibold mb-1">
                      <span><?= htmlspecialchars($paymentRow['label'], ENT_QUOTES, 'UTF-8') ?></span>
                      <span>₱<?= number_format((float) $paymentRow['kabuuan'], 2) ?></span>
                    </div>
                    <div class="progress rounded-pill" style="height: 10px; background-color: #e5e7eb;">
                      <div class="progress-bar rounded-pill" style="width: <?= (float) $paymentRow['pct'] ?>%; background-color: #087b4b;"></div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Right Card: Katayuan ng mga Reklamo -->
      <div class="col-12 col-lg-6">
        <div class="card shadow-sm border-0 rounded-4 h-100">
          <div class="card-body p-4 d-flex flex-column justify-content-between">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="stat-icon" style="width: 44px; height: 44px; font-size: 20px;">
                <i class="bi bi-shield-fill-exclamation"></i>
              </div>
              <div>
                <h5 class="fw-bold mb-0" style="color: #123b30;">Katayuan ng mga Reklamo</h5>
                <small class="text-muted">Bilang ng iyong reklamo ayon sa katayuan</small>
              </div>
            </div>

            <?php if ($complaintChartTotal === 0): ?>
              <div class="my-auto text-center py-4">
                <div class="mb-2" style="color: #b7d7c8; font-size: 48px;">
                  <i class="bi bi-check-circle-fill"></i>
                </div>
                <h6 class="fw-bold mb-1" style="color: #123b30;">Wala pang reklamo.</h6>
                <p class="text-muted small mb-0">Lahat ng iyong isinumiteng reklamo ay ipapakita rito.</p>
              </div>
            <?php else: ?>
              <?php $dotColors = ['#e59a16', '#3b82f6', '#22c55e']; ?>
              <div class="d-flex flex-column gap-4 my-auto">
                <?php foreach ($complaintChartRows as $idx => $complaintRow):
                  $color = $dotColors[$idx] ?? '#087b4b';
                ?>
                  <div>
                    <div class="d-flex align-items-center gap-2 mb-1">
                      <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: <?= $color ?>;"></span>
                      <span class="fw-semibold small" style="color: #123b30;">
                        <?= htmlspecialchars($complaintRow['label'], ENT_QUOTES, 'UTF-8') ?>
                      </span>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                      <div class="progress flex-grow-1 rounded-pill" style="height: 10px; background-color: #e5e7eb;">
                        <div class="progress-bar rounded-pill" style="width: <?= (float) $complaintRow['pct'] ?>%; background-color: <?= $color ?>;"></div>
                      </div>
                      <span class="fw-semibold small text-nowrap" style="color: #374151; min-width: 78px; text-align: right;">
                        <?= (int) $complaintRow['bilang'] ?> (<?= number_format((float) $complaintRow['pct'], 1) ?>%)
                      </span>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Quick Actions -->
  <div class="row g-3 mt-3">
    <?php
    $actions = [
        ['payments.php', 'Bayarin', 'View Payments', 'bi-credit-card-fill'],
        ['reservations.php', 'Facilities', 'Make Reservation', 'bi-calendar-plus-fill'],
        ['complaints.php', 'Concerns', 'Submit Complaint', 'bi-chat-square-text-fill'],
        ['profile.php', 'Account', 'Manage Profile', 'bi-person-gear'],
    ];
    foreach ($actions as [$href, $sub, $title, $icon]): ?>
      <div class="col-12 col-sm-6 col-xl-3">
        <a href="<?= $href ?>" class="card shadow-sm border-0 rounded-4 p-3 text-decoration-none d-flex flex-row align-items-center gap-3 h-100">
          <div class="stat-icon"><i class="bi <?= $icon ?>"></i></div>
          <div>
            <small class="text-muted d-block"><?= $sub ?></small>
            <strong style="color: #123b30;"><?= $title ?></strong>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Pinakabagong Announcements -->
  <section class="card shadow-sm border-0 rounded-4 mt-4 p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 class="fw-bold mb-0" style="color: #123b30;">Pinakabagong Announcements</h5>
      <a href="announcements.php" class="btn btn-sm btn-success rounded-pill px-3">Tingnan Lahat &rarr;</a>
    </div>

    <?php if (empty($announcementRows)): ?>
      <p class="text-muted mb-0">Wala pang announcements.</p>
    <?php else: ?>
      <div class="d-flex flex-column gap-2">
        <?php foreach ($announcementRows as $a): ?>
          <div class="p-3 rounded-3 bg-light" style="border-left: 4px solid #087b4b;">
            <div class="fw-bold" style="color: #123b30;"><?= htmlspecialchars($a['title'], ENT_QUOTES, 'UTF-8') ?></div>
            <small class="text-muted"><?= nl2br(htmlspecialchars($a['body'], ENT_QUOTES, 'UTF-8')) ?></small>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

<?php else: ?>
  <div class="page-header"><h2>Dashboard</h2></div>

<div class="row g-3 dashboard-stats">
    <?php
    $icons = [
        '<i class="bi bi-people-fill"></i>',
        '<i class="bi bi-cash-coin"></i>',
        '<i class="bi bi-exclamation-circle-fill"></i>',
        '<i class="bi bi-calendar-check-fill"></i>'
    ];
    $links = ['residents.php', 'payments.php', 'complaints.php', 'reservations.php'];
    $subtitles = ['Registered members', 'Pending collection', 'Needs resolution', 'Scheduled events'];
    $themes = [
        ['bg' => '#e5f5ed', 'color' => '#087b4b', 'border' => '#087b4b'],
        ['bg' => '#fef3c7', 'color' => '#b45309', 'border' => '#d97706'],
        ['bg' => '#fee2e2', 'color' => '#b91c1c', 'border' => '#dc2626'],
        ['bg' => '#e0f2fe', 'color' => '#0369a1', 'border' => '#0284c7'],
    ];

    foreach ($stats as $index => [$label, $value]):
        $theme = $themes[$index] ?? $themes[0];
    ?>
        <div class="col-12 col-sm-6 col-xl-3">
            <a href="<?= $links[$index] ?? '#' ?>" class="text-decoration-none">
                <div class="card shadow-sm border-0 rounded-4 dashboard-stat-card h-100" style="border-left: 4px solid <?= $theme['border'] ?> !important;">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div class="stat-info">
                            <p class="text-muted mb-1 fw-medium"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></p>
                            <h2 class="fw-bold mb-1" style="color: #123b30;"><?= htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8') ?></h2>
                            <small class="text-secondary" style="font-size: 12px;"><?= $subtitles[$index] ?? '' ?></small>
                        </div>
                        <div class="stat-icon" style="background: <?= $theme['bg'] ?>; color: <?= $theme['color'] ?>;">
                            <?= $icons[$index] ?? '<i class="bi bi-bar-chart-fill"></i>' ?>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
</div>

<section class="mt-4" aria-label="Mga chart">
    <!-- Section Heading -->
    <div class="d-flex align-items-center gap-2 mb-3">
        <i class="bi bi-bar-chart-fill" style="color: #087b4b; font-size: 20px;"></i>
        <h4 class="fw-bold mb-0" style="color: #123b30;">Mga Chart</h4>
    </div>

    <div class="row g-3">
        <!-- Left Card: Kasaysayan ng Bayad -->
        <div class="col-12 col-lg-6">
            <div class="card shadow-sm border-0 rounded-4 h-100">
                <div class="card-body p-4 d-flex flex-column">
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <div class="stat-icon" style="width: 44px; height: 44px; font-size: 20px;">
                            <i class="bi bi-wallet-fill"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0" style="color: #123b30;">Kasaysayan ng Bayad</h5>
                            <small class="text-muted">Kabuuang bayad bawat buwan (huling 6 na buwan)</small>
                        </div>
                    </div>

                    <?php if (count($paymentChartRows) === 0): ?>
                        <div class="my-auto text-center py-4">
                            <div class="position-relative d-inline-block mb-3" style="color: #b7d7c8;">
                                <i class="bi bi-bar-chart-fill" style="font-size: 64px; opacity: 0.75;"></i>
                                <i class="bi bi-search position-absolute" style="font-size: 26px; color: #5c9e82; bottom: 4px; right: -10px;"></i>
                            </div>
                            <h6 class="fw-bold mb-1" style="color: #123b30;">Wala pang datos ng bayad.</h6>
                            <p class="text-muted small mb-0 mx-auto" style="max-width: 280px;">
                                Ang kasaysayan ng bayad ay lalabas dito kapag may naitalang transaksyon.
                            </p>
                        </div>
                    <?php else: ?>
                        <div class="d-flex flex-column gap-3 my-auto">
                            <?php foreach ($paymentChartRows as $paymentRow): ?>
                                <div>
                                    <div class="d-flex justify-content-between small fw-semibold mb-1">
                                        <span><?= htmlspecialchars($paymentRow['label'], ENT_QUOTES, 'UTF-8') ?></span>
                                        <span>₱<?= number_format((float) $paymentRow['kabuuan'], 2) ?></span>
                                    </div>
                                    <div class="progress rounded-pill" style="height: 10px; background-color: #e5e7eb;">
                                        <div class="progress-bar rounded-pill" style="width: <?= (float) $paymentRow['pct'] ?>%; background-color: #087b4b;"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Right Card: Katayuan ng mga Reklamo -->
        <div class="col-12 col-lg-6">
            <div class="card shadow-sm border-0 rounded-4 h-100">
                <div class="card-body p-4 d-flex flex-column justify-content-between">
                    <div class="d-flex align-items-center gap-3 mb-4">
                        <div class="stat-icon" style="width: 44px; height: 44px; font-size: 20px;">
                            <i class="bi bi-shield-fill-exclamation"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0" style="color: #123b30;">Katayuan ng mga Reklamo</h5>
                            <small class="text-muted">Bilang ng reklamo ayon sa katayuan</small>
                        </div>
                    </div>

                    <?php if ($complaintChartTotal === 0): ?>
                        <p class="text-muted text-center my-auto">Wala pang reklamo.</p>
                    <?php else: ?>
                        <?php
                        $dotColors = ['#e59a16', '#3b82f6', '#22c55e'];
                        ?>
                        <div class="d-flex flex-column gap-4 my-auto">
                            <?php foreach ($complaintChartRows as $idx => $complaintRow):
                                $color = $dotColors[$idx] ?? '#087b4b';
                            ?>
                                <div>
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="rounded-circle d-inline-block" style="width: 9px; height: 9px; background-color: <?= $color ?>;"></span>
                                        <span class="fw-semibold small" style="color: #123b30;">
                                            <?= htmlspecialchars($complaintRow['label'], ENT_QUOTES, 'UTF-8') ?>
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="progress flex-grow-1 rounded-pill" style="height: 10px; background-color: #e5e7eb;">
                                            <div class="progress-bar rounded-pill" style="width: <?= (float) $complaintRow['pct'] ?>%; background-color: <?= $color ?>;"></div>
                                        </div>
                                        <span class="fw-semibold small text-nowrap" style="color: #374151; min-width: 78px; text-align: right;">
                                            <?= (int) $complaintRow['bilang'] ?> (<?= number_format((float) $complaintRow['pct'], 1) ?>%)
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="card shadow-sm border-0 rounded-4 mt-4 p-4">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div class="d-flex align-items-center gap-3">
            <div class="stat-icon" style="width: 44px; height: 44px; font-size: 20px;">
                <i class="bi bi-megaphone-fill"></i>
            </div>
            <div>
                <h5 class="fw-bold mb-0" style="color: #123b30;">Pinakabagong Announcements</h5>
                <small class="text-muted">Mga kamakailang abiso para sa komunidad</small>
            </div>
        </div>
        <a href="announcements.php" class="btn btn-sm btn-dark rounded-pill px-3" style="background-color: #123b30;">
            Tingnan Lahat &rarr;
        </a>
    </div>

    <?php if (count($announcementRows) === 0): ?>
        <p class="text-muted mb-0">Wala pang announcements.</p>
    <?php else: ?>
        <div class="d-flex flex-column gap-2">
            <?php foreach ($announcementRows as $announcement): ?>
                <div class="p-3 rounded-3 bg-light" style="border-left: 4px solid #087b4b;">
                    <div class="fw-bold" style="color: #123b30;"><?= htmlspecialchars($announcement['title'], ENT_QUOTES, 'UTF-8') ?></div>
                    <small class="text-muted"><?= nl2br(htmlspecialchars($announcement['body'], ENT_QUOTES, 'UTF-8')) ?></small>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
