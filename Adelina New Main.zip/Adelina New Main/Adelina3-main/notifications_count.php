<?php
// Nagbabalik ng bilang ng hindi pa nababasang notification ng naka-login na user (JSON).
// Ginagamit ito ng live bell badge para mag-update nang hindi nire-reload ang page.
require_once 'includes/helpers.php';
require_once 'includes/db.php';

start_secure_session();
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['unread' => 0]);
    exit;
}

$userId = (int) $_SESSION['user_id'];
$unread = function_exists('unreadNotificationCount') ? unreadNotificationCount($conn, $userId) : 0;
echo json_encode(['unread' => $unread]);
