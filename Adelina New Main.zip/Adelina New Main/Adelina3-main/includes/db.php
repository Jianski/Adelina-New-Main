<?php
// Binubuksan ang koneksyon sa MySQL database na ginagamit ng HOA application.
date_default_timezone_set('Asia/Manila');

$host = getenv('HOA_DB_HOST') ?: 'localhost';
$user = getenv('HOA_DB_USER') ?: 'root';
$pass = getenv('HOA_DB_PASSWORD');
$pass = $pass === false ? '' : $pass;
$dbname = getenv('HOA_DB_NAME') ?: 'adelina3_hoa';

$conn = new mysqli($host, $user, $pass, $dbname);

// Hindi inilalantad ang detalye ng database error sa user; sa error log lang ito.
if ($conn->connect_error) {
    error_log('Database connection failed: ' . $conn->connect_error);
    http_response_code(500);
    die('Hindi makakonekta sa database. Subukan muli mamaya.');
}

$conn->set_charset('utf8mb4');
$conn->query("SET time_zone = '+08:00'");
?>
