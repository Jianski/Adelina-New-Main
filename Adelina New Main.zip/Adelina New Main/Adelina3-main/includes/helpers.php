<?php
// Shared security helpers: ligtas na session, CSRF token at ligtas na pagbasa ng POST input.
// Lahat ng page ay naglo-load nito bago mag-session_start() o magbasa ng $_POST.

// Hindi ipinapakita ang PHP error sa screen (baka makita ng user ang
// detalye ng server); naka-log lang ito sa PHP error log.
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Sinisimulan ang session na may HttpOnly + SameSite=Lax cookies upang mahirap
// nakawin ang session ID sa pamamagitan ng JavaScript o cross-site request.
function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}

// Ibinabalik ang CSRF token ng session; gumagawa ng bago kung wala pa.
function csrf_token(): string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        start_secure_session();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf_token'];
}

// Sinusuri kung galing sa sariling form ang POST request.
function csrf_check($postedToken): bool
{
    if (!is_string($postedToken) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals((string) $_SESSION['csrf_token'], $postedToken);
}

// Ligtas na pagbasa ng string mula sa $_POST: hindi nagkaka-TypeError
// kahit magpadala ng array ang attacker (hal. password[]=x).
function post_string(string $key, string $default = ''): string
{
    $value = $_POST[$key] ?? $default;
    return is_string($value) ? $value : $default;
}

// Ligtas na pagbasa ng integer mula sa $_POST.
function post_int(string $key, int $default = 0): int
{
    $value = filter_var($_POST[$key] ?? null, FILTER_VALIDATE_INT);
    return $value === false ? $default : (int) $value;
}

// Binabasa ang page number nang ligtas at ibinabalik sa unang page ang invalid na input.
function paginationPage(string $key = 'page'): int
{
    $value = filter_var(
        $_GET[$key] ?? null,
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1]]
    );
    return $value === false || $value === null ? 1 : (int) $value;
}

// Gumagawa ng navigation links habang pinananatili ang kasalukuyang GET filters.
function renderPagination(int $currentPage, int $totalPages, array $queryParams = []): void
{
    if ($totalPages <= 1) {
        return;
    }

    $renderLink = static function (int $page, string $label, string $ariaLabel = '') use ($queryParams): string {
        $params = $queryParams;
        $params['page'] = $page;
        $href = '?' . http_build_query($params);
        $aria = $ariaLabel !== '' ? ' aria-label="' . htmlspecialchars($ariaLabel, ENT_QUOTES, 'UTF-8') . '"' : '';
        return '<a class="pagination-link" href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '"' . $aria . '>'
            . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</a>';
    };

    echo '<nav class="pagination" aria-label="Pagination">';
    if ($currentPage > 1) {
        echo $renderLink($currentPage - 1, 'Previous', 'Previous page');
    }

    $startPage = max(1, $currentPage - 2);
    $endPage = min($totalPages, $currentPage + 2);

    if ($startPage > 1) {
        echo $renderLink(1, '1');
        if ($startPage > 2) {
            echo '<span class="pagination-ellipsis" aria-hidden="true">&hellip;</span>';
        }
    }

    for ($page = $startPage; $page <= $endPage; $page++) {
        if ($page === $currentPage) {
            echo '<span class="pagination-current" aria-current="page">' . $page . '</span>';
        } else {
            echo $renderLink($page, (string) $page, 'Page ' . $page);
        }
    }

    if ($endPage < $totalPages) {
        if ($endPage < $totalPages - 1) {
            echo '<span class="pagination-ellipsis" aria-hidden="true">&hellip;</span>';
        }
        echo $renderLink($totalPages, (string) $totalPages);
    }

    if ($currentPage < $totalPages) {
        echo $renderLink($currentPage + 1, 'Next', 'Next page');
    }
    echo '<span class="pagination-summary">Page ' . $currentPage . ' of ' . $totalPages . '</span>';
    echo '</nav>';
}

// Shortcut para sa pag-escape ng output laban sa XSS.
function esc($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Sinusuri kung 12–64 character ang bagong password (min 12, max 64).
// Ang 72-byte limit ng bcrypt ay sine-check din para hindi ito tahimik
// na maputol kapag may multibyte character ang password.
function isValidNewPassword(string $password): bool
{
    $chars = mb_strlen($password, 'UTF-8');
    return $chars >= 12 && $chars <= 64 && strlen($password) <= 72;
}

// Inaalam kung may account_status column na ang users table (para hindi
// mag-error ang login/register kung hindi pa na-apply ang migration).
function usersHasAccountStatus(mysqli $conn): bool
{
    static $hasColumn = null;
    if ($hasColumn !== null) {
        return $hasColumn;
    }
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'account_status'");
        $hasColumn = $result !== false && $result->num_rows > 0;
    } catch (mysqli_sql_exception $exception) {
        $hasColumn = false;
    }
    return $hasColumn;
}

// Sinasabi kung naka-block na ang email dahil sa 5 maling pagtatangka
// sa nakaraang 10 minuto (database-based para hindi malampasan sa
// pag-clear ng cookies). Kapag wala pa ang login_attempts table,
// bumabalik ito sa false at ang session-based na throttling na lang
// ang gumagana.
function loginBlockedByDatabase(mysqli $conn, string $email): bool
{
    if ($email === '') {
        return false;
    }
    try {
        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS c FROM login_attempts
             WHERE email = ? AND success = 0
               AND attempted_at > (NOW() - INTERVAL 10 MINUTE)"
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        return (int) ($row['c'] ?? 0) >= 5;
    } catch (mysqli_sql_exception $exception) {
        return false;
    }
}

// Nagtatala ng login attempt sa database para sa throttling.
function recordLoginAttempt(mysqli $conn, string $email, bool $success): void
{
    if ($email === '') {
        return;
    }
    try {
        $stmt = $conn->prepare(
            'INSERT INTO login_attempts (email, attempted_at, success) VALUES (?, NOW(), ?)'
        );
        $successFlag = $success ? 1 : 0;
        $stmt->bind_param('si', $email, $successFlag);
        $stmt->execute();
        // Nililinis ang mga lumang record para hindi lumaki ang table.
        $conn->query('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 1 DAY)');
    } catch (mysqli_sql_exception $exception) {
        // Kapag wala pa ang table, session-based throttling pa rin ang gumagana.
    }
}

// Nagtatala ng mahalagang aksyon (payments, pagbura, approval) sa audit_log.
// Hindi ito humihinto sa main action kahit mag-fail ang pag-log.
function logAudit(mysqli $conn, ?int $userId, string $action, string $details = ''): void
{
    try {
        $stmt = $conn->prepare(
            'INSERT INTO audit_log (user_id, action, details) VALUES (?, ?, ?)'
        );
        $stmt->bind_param('iss', $userId, $action, $details);
        $stmt->execute();
    } catch (mysqli_sql_exception $exception) {
        error_log('Audit log failed: ' . $exception->getMessage());
    }
}

// Nag-iinsert ng notification para sa isang user (hal. na-approve ang
// payment, reservation o complaint). Hindi ito humihinto sa main action
// kahit mag-fail (hal. wala pa ang notifications table).
function notifyUser(mysqli $conn, int $userId, string $type, string $title, string $message, string $link = ''): void
{
    if ($userId <= 0) {
        return;
    }
    try {
        $stmt = $conn->prepare(
            'INSERT INTO notifications (user_id, type, title, message, link) VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->bind_param('issss', $userId, $type, $title, $message, $link);
        $stmt->execute();
    } catch (mysqli_sql_exception $exception) {
        error_log('Notification failed: ' . $exception->getMessage());
    }
}

 // Nagpapadala ng notification sa LAHAT ng resident (hal. bagong announcement).
 // Isang query lang (INSERT ... SELECT); tahimik na hindi gumagawa ng anuman
 // kapag wala pa ang notifications table.
function notifyAllResidents(mysqli $conn, string $type, string $title, string $message, string $link = ''): void
{
    try {
        $stmt = $conn->prepare(
            'INSERT INTO notifications (user_id, type, title, message, link) '
            . 'SELECT user_id, ?, ?, ?, ? FROM users WHERE role = ?'
        );
        $role = 'resident';
        $stmt->bind_param('sssss', $type, $title, $message, $link, $role);
        $stmt->execute();
    } catch (mysqli_sql_exception $exception) {
        error_log('Notification to all residents failed: ' . $exception->getMessage());
    }
}

// Nagpapadala ng notification sa LAHAT ng admin at officer (hal. may bagong
// reklamo, reservation, bayad o rehistro ang resident). Isang query lang
// (INSERT ... SELECT); tahimik na hindi gumagawa ng anuman kapag wala pa
// ang notifications table.
function notifyStaff(mysqli $conn, string $type, string $title, string $message, string $link = ''): void
{
    try {
        $stmt = $conn->prepare(
            'INSERT INTO notifications (user_id, type, title, message, link) '
            . "SELECT user_id, ?, ?, ?, ? FROM users WHERE role IN ('admin', 'officer')"
        );
        $stmt->bind_param('ssss', $type, $title, $message, $link);
        $stmt->execute();
    } catch (mysqli_sql_exception $exception) {
        error_log('Notification to staff failed: ' . $exception->getMessage());
    }
}

// Binibilang ang hindi pa nababasang notification ng isang user.
// Bumabalik sa 0 kapag wala pa ang notifications table.
function unreadNotificationCount(mysqli $conn, int $userId): int
{
    if ($userId <= 0) {
        return 0;
    }
    try {
        $stmt = $conn->prepare(
            'SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0'
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        return (int) ($row['c'] ?? 0);
    } catch (mysqli_sql_exception $exception) {
        return 0;
    }
}
