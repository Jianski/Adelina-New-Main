<?php
// Set HOA_MAIL_PASSWORD in the PHP environment; never store credentials here.
$mailPassword = getenv('HOA_MAIL_PASSWORD') ?: '';
