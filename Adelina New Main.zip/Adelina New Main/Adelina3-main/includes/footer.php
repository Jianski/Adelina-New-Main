      <!-- Dito ipinapasok ng bawat page ang sariling nilalaman sa loob ng shared layout. -->
      </main>
    </div>
  </div>
  <!-- Cookie consent banner: lumalabas lang hangga't hindi pa pumipili ang user. -->
  <div class="cookie-banner" id="cookieBanner" hidden>
    <p><span data-i18n="cookie.text">Gumagamit ang site na ito ng cookies para mapanatili kang naka-login. Basahin ang aming</span> <a href="privacy.php">Privacy Policy</a>.</p>
    <div class="cookie-banner-actions">
      <button type="button" class="btn btn-primary btn-small" id="cookieAccept" data-i18n="cookie.accept">Tanggapin</button>
      <button type="button" class="btn btn-small" id="cookieDecline" data-i18n="cookie.decline">Tanggihan</button>
    </div>
  </div>
  <!-- Nagbibigay ng mobile navigation, search at confirmation behavior sa mga page. -->
  <script src="assets/js/script.js?v=<?= (int) filemtime(__DIR__ . '/../assets/js/script.js') ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.9/dist/js/bootstrap.bundle.min.js"></script>
  <script>
  (function () {
    const html = document.documentElement;
    const btn = document.getElementById('themeToggle');
    const icon = document.getElementById('themeIcon');

    if (localStorage.getItem('theme') === 'dark') {
      html.setAttribute('data-theme', 'dark');
      if (icon) icon.className = 'bi bi-sun-fill text-warning';
    }

    if (btn) {
      btn.addEventListener('click', function () {
        const isDark = html.getAttribute('data-theme') === 'dark';
        if (isDark) {
          html.removeAttribute('data-theme');
          localStorage.setItem('theme', 'light');
          if (icon) icon.className = 'bi bi-moon-fill';
        } else {
          html.setAttribute('data-theme', 'dark');
          localStorage.setItem('theme', 'dark');
          if (icon) icon.className = 'bi bi-sun-fill text-warning';
        }
      });
    }
  })();
</script>

</body>
</html>
