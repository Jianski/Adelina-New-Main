<?php
// Tinitiyak na may aktibong session bago payagang bumukas ang mga pribadong page.
require_once __DIR__ . '/helpers.php';
start_secure_session();


// Nag-e-expire ang session pagkatapos ng 30 minutong walang galaw.
$sessionTimeoutSeconds = 30 * 60;
if (
    isset($_SESSION['last_activity'])
    && time() - (int) $_SESSION['last_activity'] > $sessionTimeoutSeconds
) {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php?session_expired=1');
    exit;
}
$_SESSION['last_activity'] = time();

// Ibinabalik sa login page ang sinumang walang authenticated user ID.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Database ang pinagmumulan ng account at role upang hindi pagkatiwalaan ang lumang session role.
require_once __DIR__ . '/db.php';
$authenticatedUserId = (int) $_SESSION['user_id'];
$userStmt = $conn->prepare('SELECT user_id, full_name, role FROM users WHERE user_id = ? LIMIT 1');
$userStmt->bind_param('i', $authenticatedUserId);
$userStmt->execute();
$authenticatedUser = $userStmt->get_result()->fetch_assoc();

if (!$authenticatedUser) {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php?session_expired=1');
    exit;
}

$authenticatedRole = strtolower((string) $authenticatedUser['role']);
if (!in_array($authenticatedRole, ['admin', 'officer', 'resident'], true)) {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php?access_denied=1');
    exit;
}

$_SESSION['role'] = $authenticatedRole;
$_SESSION['full_name'] = $authenticatedUser['full_name'];
