<?php
// Ibinabahagi ng lahat ng authenticated page ang title, navigation at pambungad na HTML layout.
require_once __DIR__ . '/auth.php';
$pageTitle = $pageTitle ?? 'Adelina 3 Homeowners Association';
$currentPage = basename($_SERVER['PHP_SELF']);
$userName = trim((string) ($_SESSION['full_name'] ?? ''));
$userRole = ucfirst((string) ($_SESSION['role'] ?? ''));
$showUserRole = $userName === '' || strcasecmp($userName, $userRole) !== 0;
// Bilang ng hindi pa nababasang notification para sa bell icon.
$unreadCount = 0;
if (isset($conn, $_SESSION['user_id']) && function_exists('unreadNotificationCount')) {
    $unreadCount = unreadNotificationCount($conn, (int) $_SESSION['user_id']);
}
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?> | Adelina 3 Homeowners Association</title>
  <link rel="icon" type="image/png" href="/favicon.png">
  <link rel="manifest" href="manifest.webmanifest">
  <meta name="theme-color" content="#193b34">
  <link rel="apple-touch-icon" href="assets/images/icon-192.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.9/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/css/style.css?v=<?= (int) filemtime(__DIR__ . '/../assets/css/style.css') ?>">
</head>
<body<?= in_array($currentPage, ['reservations.php', 'reports.php'], true) ? ' class="' . ($currentPage === 'reservations.php' ? 'reservations-page' : 'reports-page') . '"' : '' ?>>
  <div class="layout">
    <!-- Ipinapakita ang navigation ayon sa role at minamarkahan ang kasalukuyang page. -->
    <aside class="sidebar" id="sidebar">
      <button class="sidebar-back" id="sidebarBack" type="button" aria-label="Isara ang menu">&larr; Back</button>
      <div class="brand"><img src="assets/images/logo.png" alt="Adelina 3 Homeowners Association logo"></div>
      <nav aria-label="Main navigation">
        <a href="dashboard.php"<?= $currentPage === 'dashboard.php' ? ' class="active" aria-current="page"' : '' ?>>Dashboard</a>
        <?php if (in_array($_SESSION['role'] ?? '', ['admin', 'officer'], true)): ?>
          <a href="residents.php"<?= $currentPage === 'residents.php' ? ' class="active" aria-current="page"' : '' ?>>Residents</a>
        <?php endif; ?>
        <a href="payments.php"<?= $currentPage === 'payments.php' ? ' class="active" aria-current="page"' : '' ?>>Payments</a>
        <a href="announcements.php"<?= $currentPage === 'announcements.php' ? ' class="active" aria-current="page"' : '' ?>>Announcements</a>
        <a href="complaints.php"<?= $currentPage === 'complaints.php' ? ' class="active" aria-current="page"' : '' ?>>Complaints / Report</a>
        <a href="reservations.php"<?= $currentPage === 'reservations.php' ? ' class="active" aria-current="page"' : '' ?>>Reservations</a>
        <a href="schedule.php"<?= $currentPage === 'schedule.php' ? ' class="active" aria-current="page"' : '' ?>>Schedule of Facility</a>
        <?php if (in_array($_SESSION['role'] ?? '', ['admin', 'officer'], true)): ?>
          <a href="reports.php"<?= $currentPage === 'reports.php' ? ' class="active" aria-current="page"' : '' ?>>Reports</a>
        <?php endif; ?>
        <a href="profile.php"<?= $currentPage === 'profile.php' ? ' class="active" aria-current="page"' : '' ?>>Profile</a>
        <a href="privacy.php">Privacy Policy</a>
        <a href="terms.php">Terms &amp; Conditions</a>
        <a href="logout.php" class="confirm-link" data-confirm="Sigurado ka bang gusto mong mag-log out?" data-i18n="nav.logout">Logout</a>
      </nav>
    </aside>
    <button class="sidebar-backdrop" id="sidebarBackdrop" type="button" aria-label="Isara ang menu" hidden></button>
    <div class="main">
      <!-- Ipinapakita ang kasalukuyang user; ang menu button ay para sa maliit na screen. -->
      <header class="topbar">
        <button class="menu-btn" id="menuBtn" type="button" aria-controls="sidebar" aria-expanded="false">☰ Menu</button>
        <span><span data-i18n="greet">Kumusta</span>, <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?><?= $showUserRole ? ' (' . htmlspecialchars($userRole, ENT_QUOTES, 'UTF-8') . ')' : '' ?></span>
        <button type="button" class="topbar-print no-print" onclick="window.print()" aria-label="I-print ang page na ito" title="Print">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
        </button>
        <a class="notif-bell" href="notifications.php" aria-label="Mga notification"> 
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
          <?php if ($unreadCount > 0): ?>
            <span class="notif-badge"><?= $unreadCount > 99 ? '99+' : (int) $unreadCount ?></span>
          <?php endif; ?>
        </a>
        <button id="themeToggle" type="button" class="btn btn-sm btn-light rounded-circle border" title="Toggle Dark Mode" style="width: 38px; height: 38px;">
  <i class="bi bi-moon-fill" id="themeIcon"></i>
</button>

      </header>
      <main class="content">
