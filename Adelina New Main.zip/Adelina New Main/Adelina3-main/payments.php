<?php
// Ipinapakita sa resident ang sariling balanse at pinamamahalaan ng staff ang payment records.
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Payments';
$role = $_SESSION['role'] ?? 'resident';
$userId = (int) $_SESSION['user_id'];
$actorName = trim((string) ($_SESSION['full_name'] ?? ''));
$error = '';
$description = 'HOA Dues';
$message = $_SESSION['payment_message'] ?? '';
unset($_SESSION['payment_message']);

// Kinukuha ang resident ID ng kasalukuyang user at inihahanda ang CSRF protection ng mga form.
$csrfToken = csrf_token();

$residentId = 0;
if ($role === 'resident') {
    $residentStmt = $conn->prepare('SELECT resident_id FROM residents WHERE user_id = ? LIMIT 1');
    $residentStmt->bind_param('i', $userId);
    $residentStmt->execute();
    $resident = $residentStmt->get_result()->fetch_assoc();
    if ($resident) {
        $residentId = (int) $resident['resident_id'];
    }
}

$isStaff = in_array($role, ['admin', 'officer'], true);

// Bawat payment action ay sinusuri muna ang token at awtorisadong role bago baguhin ang data.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        $error = 'Nag-expire o hindi wasto ang request. I-refresh ang page at subukan muli.';
    } elseif (isset($_POST['clear_payments'])) {
        if ($role !== 'admin') {
            http_response_code(403);
            $error = 'Admin lang ang maaaring magbura ng lahat ng payment history.';
        } else {
            try {
                $conn->query('DELETE FROM payments');
                logAudit($conn, $userId, 'clear_payments', 'Binura ang lahat ng payment history.');
                $_SESSION['payment_message'] = 'Nabura na ang lahat ng payment history.';
                header('Location: payments.php');
                exit;
            } catch (mysqli_sql_exception $exception) {
                error_log('Clear payments failed: ' . $exception->getMessage());
                $error = 'Hindi nabura ang payment history. Subukan muli.';
            }
        }
    } elseif (isset($_POST['upload_payment_proof']) && $role === 'resident') {
        $paymentId = (int) ($_POST['payment_id'] ?? 0);
        $proofFile = $_FILES['payment_proof'] ?? null;
        $proofName = '';
        $proofData = null;
        $proofMime = null;
        $proofExtensions = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'application/pdf' => 'pdf',
        ];

        if ($residentId < 1 || $paymentId < 1) {
            $error = 'Hindi makita ang payment record.';
        } elseif (!is_array($proofFile) || ($proofFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
            || !isset($proofFile['size'], $proofFile['tmp_name'])
            || $proofFile['size'] > 5 * 1024 * 1024 || !is_uploaded_file($proofFile['tmp_name'])) {
            $error = 'Pumili ng JPG, PNG, WEBP, o PDF na hanggang 5 MB.';
        } else {
            $fileInfo = new finfo(FILEINFO_MIME_TYPE);
            $detectedMime = $fileInfo->file($proofFile['tmp_name']);
            if (!is_string($detectedMime) || !isset($proofExtensions[$detectedMime])) {
                $error = 'Mag-upload ng JPG, PNG, WEBP, o PDF payment proof.';
            }
        }

        if ($error === '') {
            // Naka-save na sa database ang proof, hindi na sa folder,
            // para hindi na kailangan ng folder permission sa hosting.
            $proofName = bin2hex(random_bytes(16)) . '.' . $proofExtensions[$detectedMime];
            $proofData = file_get_contents($proofFile['tmp_name']);
            $proofMime = $detectedMime;
            if ($proofData === false) {
                $error = 'Hindi na-save ang payment proof. Subukan muli.';
                $proofName = '';
                $proofData = null;
                $proofMime = null;
            }
        }

        if ($error === '') {
            $attachStmt = $conn->prepare(
                "UPDATE payments SET payment_proof = ?, payment_proof_data = ?, payment_proof_mime = ?
                 WHERE payment_id = ? AND resident_id = ? AND status = 'Unpaid'
                   AND approval_status = 'Pending' AND (payment_proof IS NULL OR payment_proof = '')"
            );
            $attachStmt->bind_param('sssii', $proofName, $proofData, $proofMime, $paymentId, $residentId);
            $attachStmt->execute();
            if ($attachStmt->affected_rows > 0) {
                // Ipaalam sa admin/officer na may bagong payment proof ang resident.
                $proofInfoStmt = $conn->prepare('SELECT description, amount FROM payments WHERE payment_id = ?');
                $proofInfoStmt->bind_param('i', $paymentId);
                $proofInfoStmt->execute();
                $proofInfo = $proofInfoStmt->get_result()->fetch_assoc();
                $proofLabel = trim((string) ($proofInfo['description'] ?? ''));
                if ($proofLabel === '') {
                    $proofLabel = 'dues';
                }
                $proofAmount = number_format((float) ($proofInfo['amount'] ?? 0), 2);
                notifyStaff(
                    $conn,
                    'payment',
                    'Bagong payment proof',
                    ($actorName !== '' ? $actorName . ' — ' : '') . $proofLabel . ' (₱' . $proofAmount . ')',
                    'payments.php'
                );
                $_SESSION['payment_message'] = 'Naidagdag ang proof. Makikita na ito ng admin sa payment record.';
            } else {
                $_SESSION['payment_message'] = 'Hindi naidagdag ang proof. Maaaring may proof na ito o na-update na ang payment.';
            }
            header('Location: payments.php');
            exit;
        }
    } elseif (isset($_POST['pay_now']) && $role === 'resident') {
        if ($residentId < 1) {
            $error = 'Wala pang resident profile na naka-link sa account mo.';
        } else {
            $paymentOption = trim(post_string('payment_option'));
            $paymentReference = trim(post_string('payment_reference'));
            $validOptions = ['Cash', 'GCash', 'Online Bank'];

            if (!in_array($paymentOption, $validOptions, true)) {
                $error = 'Piliin ang payment option.';
            } else {
                $paymentMethod = $paymentOption === 'Cash' ? 'Cash' : 'Online Payment';
                $paymentProvider = $paymentOption === 'Cash' ? null : $paymentOption;
                $proofFile = $_FILES['payment_proof'] ?? null;
                $proofName = '';
                $proofData = null;
                $proofMime = null;

                // Puwedeng mag-attach ng resibo sa Cash; required pa rin ito sa online payment.
                $hasProof = is_array($proofFile) && ($proofFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
                if ($paymentOption !== 'Cash' || $hasProof) {
                    if ($paymentOption !== 'Cash' && $paymentReference === '') {
                        $error = 'Maglagay ng transaction/reference number para sa online payment.';
                    } elseif ($paymentOption === 'GCash' && !preg_match('/\A[0-9]{13}\z/', $paymentReference)) {
                        $error = 'Dapat eksaktong 13 digit ang GCash reference number.';
                    } elseif ($paymentOption === 'Online Bank' && !preg_match('/\A[0-9]{1,100}\z/', $paymentReference)) {
                        $error = 'Dapat numero lamang ang bank reference number (hanggang 100 digit).';
                    } elseif (!$proofFile || !is_array($proofFile) || $proofFile['error'] === UPLOAD_ERR_NO_FILE) {
                        $error = 'Mag-upload ng proof of payment para sa online payment.';
                    } elseif ($proofFile['error'] !== UPLOAD_ERR_OK
                        || !isset($proofFile['size'], $proofFile['tmp_name'])
                        || $proofFile['size'] > 5 * 1024 * 1024
                        || !is_uploaded_file($proofFile['tmp_name'])) {
                        $error = 'Invalid o lumampas sa 5 MB ang payment proof.';
                    } else {
                        // Ang extension ay galing sa totoong file type, hindi sa pangalan
                        // na ipinasa ng user, para hindi maitago ang script bilang image.
                        $proofExtensions = [
                            'image/jpeg' => 'jpg',
                            'image/png' => 'png',
                            'image/webp' => 'webp',
                            'application/pdf' => 'pdf',
                        ];
                        $fileInfo = new finfo(FILEINFO_MIME_TYPE);
                        $detectedMime = $fileInfo->file($proofFile['tmp_name']);
                        if (!is_string($detectedMime) || !isset($proofExtensions[$detectedMime])) {
                            $error = 'Mag-upload ng JPG, PNG, WEBP, o PDF payment proof.';
                        } else {
                            // Naka-save na sa database ang proof, hindi na sa folder,
                            // para hindi na kailangan ng folder permission sa hosting.
                            $proofName = bin2hex(random_bytes(16)) . '.' . $proofExtensions[$detectedMime];
                            $proofData = file_get_contents($proofFile['tmp_name']);
                            $proofMime = $detectedMime;
                            if ($proofData === false) {
                                $error = 'Hindi na-save ang payment proof. Subukan muli.';
                                $proofName = '';
                                $proofData = null;
                                $proofMime = null;
                            }
                        }
                    }
                }

                if ($error === '') {
                    // Ang dating Pending na submission ay hindi na ginagalaw;
                    // ang Rejected o bagong dues lang ang puwedeng bayaran uli.
                    $payStmt = $conn->prepare(
                        "UPDATE payments
                         SET approval_status = 'Pending',
                             date_paid = NULL,
                             payment_method = ?, payment_provider = ?,
                             payment_reference = ?, payment_proof = ?,
                             payment_proof_data = ?, payment_proof_mime = ?
                         WHERE resident_id = ? AND status = 'Unpaid'
                           AND (approval_status IS NULL OR approval_status = 'Rejected')"
                    );
                    $payStmt->bind_param(
                        'ssssssi',
                        $paymentMethod,
                        $paymentProvider,
                        $paymentReference,
                        $proofName,
                        $proofData,
                        $proofMime,
                        $residentId
                    );
                    $payStmt->execute();

                    if ($payStmt->affected_rows > 0) {
                        // Ipaalam sa admin/officer na may bagong bayad ang resident.
                        notifyStaff(
                            $conn,
                            'payment',
                            'Bagong bayad',
                            ($actorName !== '' ? $actorName . ' — ' : '') . $paymentMethod . ($paymentReference !== '' ? ' (Ref: ' . $paymentReference . ')' : ''),
                            'payments.php'
                        );
                        $_SESSION['payment_message'] = 'Na-submit ang payment at naghihintay ng admin validation.';
                    } else {
                        // Walang nabago: baka naghihintay pa ng validation ang nauna.
                        $_SESSION['payment_message'] = 'Wala kang unpaid dues na kailangang bayaran o naghihintay pa ng validation ang nauna mong payment.';
                    }
                    header('Location: payments.php');
                    exit;
                }
            }
        }
    } elseif (isset($_POST['record_payment']) && $isStaff) {
        $selectedResidentId = filter_var(
            $_POST['resident_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );
        $description = trim(post_string('description'));
        $amountInput = post_string('amount');
        $dueDate = trim(post_string('due_date'));
        $amount = filter_var($amountInput, FILTER_VALIDATE_FLOAT);
        $validDate = $dueDate === '';

        if ($dueDate !== '') {
            $parsedDate = DateTime::createFromFormat('!Y-m-d', $dueDate);
            $validDate = $parsedDate !== false && $parsedDate->format('Y-m-d') === $dueDate;
        }

        if (strcasecmp($description, 'Other Fees') === 0 || preg_match('/^Other Fees\s*:\s*$/i', $description)) {
            $error = 'Ilagay ang dahilan mismo sa Description, halimbawa: Other Fees: gate repair.';
        } elseif ($description === '' || mb_strlen($description) > 100) {
            $error = 'Punan ang Description (hanggang 100 character).';
        } elseif ($selectedResidentId === false) {
            $error = 'Pumili ng resident mula sa mga Block at Lot na mungkahi.';
        } elseif (
            $amount === false
            || !is_finite((float) $amount)
            || $amount <= 0
            || $amount > 99999999.99
            || !$validDate
            || $dueDate === ''
        ) {
            $error = 'Suriin ang resident, description, amount, at due date.';
        } else {
            $selectedResidentId = (int) $selectedResidentId;
            $amount = (float) $amount;
            $status = 'Unpaid';

            $checkResident = $conn->prepare(
                "SELECT resident_id FROM residents
                 WHERE resident_id = ? AND status = 'active'
                   AND blk BETWEEN 1 AND 100 AND lot BETWEEN 1 AND 100"
            );
            $checkResident->bind_param('i', $selectedResidentId);
            $checkResident->execute();

            if (!$checkResident->get_result()->fetch_assoc()) {
                $error = 'Hindi makita ang napiling resident.';
            } else {
                $insertStmt = $conn->prepare(
                    'INSERT INTO payments (resident_id, description, amount, due_date, status)
                     VALUES (?, ?, ?, ?, ?)'
                );
                $insertStmt->bind_param(
                    'isdss',
                    $selectedResidentId,
                    $description,
                    $amount,
                    $dueDate,
                    $status
                );
                $insertStmt->execute();
                logAudit($conn, $userId, 'record_payment', 'Nag-record ng ' . number_format($amount, 2) . ' na bayad para sa resident_id=' . $selectedResidentId . ' (' . $description . ').');

                $_SESSION['payment_message'] = 'Matagumpay na na-record ang payment.';
                header('Location: payments.php');
                exit;
            }
        }
    } elseif (isset($_POST['delete_payment']) && $isStaff) {
        $paymentId = filter_var(
            $_POST['payment_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        if ($paymentId === false) {
            $error = 'Hindi wasto ang payment history na pinili.';
        } else {
            $proofStmt = $conn->prepare('SELECT payment_proof FROM payments WHERE payment_id = ?');
            $proofStmt->bind_param('i', $paymentId);
            $proofStmt->execute();
            $paymentRow = $proofStmt->get_result()->fetch_assoc();
            $proofToDelete = (string) ($paymentRow['payment_proof'] ?? '');

            $deleteStmt = $conn->prepare('DELETE FROM payments WHERE payment_id = ?');
            $deleteStmt->bind_param('i', $paymentId);
            $deleteStmt->execute();

            if ($deleteStmt->affected_rows > 0) {
                logAudit($conn, $userId, 'delete_payment', 'Binura ang payment (payment_id=' . $paymentId . ').');
                // Burahin din ang proof file para hindi maiwan sa server.
                if (preg_match('/\A[a-f0-9]{32}\.(?:jpg|jpeg|png|webp|pdf)\z/i', $proofToDelete)) {
                    $proofPath = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'hoa-payment-proofs' . DIRECTORY_SEPARATOR . $proofToDelete;
                    if (is_file($proofPath)) {
                        unlink($proofPath);
                    }
                }
                $_SESSION['payment_message'] = 'Natanggal na ang payment history.';
            } else {
                $_SESSION['payment_message'] = 'Hindi natagpuan ang payment history na tatanggalin.';
            }
            header('Location: payments.php');
            exit;
        }
    } elseif (isset($_POST['validate_payment']) && $isStaff) {
        $paymentId = filter_var(
            $_POST['payment_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );
        $decision = post_string('decision');

        if ($paymentId === false || !in_array($decision, ['Approved', 'Rejected'], true)) {
            $error = 'Hindi wasto ang payment validation.';
        } else {
            // Kinukuha ang detalye ng payment para sa notification sa resident.
            $paymentInfo = null;
            $paymentInfoStmt = $conn->prepare(
                'SELECT p.description, p.amount, r.user_id
                 FROM payments p
                 JOIN residents r ON p.resident_id = r.resident_id
                 WHERE p.payment_id = ?'
            );
            $paymentInfoStmt->bind_param('i', $paymentId);
            $paymentInfoStmt->execute();
            $paymentInfo = $paymentInfoStmt->get_result()->fetch_assoc();

            // Pending lang ang puwedeng i-validate: hindi na puwedeng baligtarin
            // ang na-approve o na-reject nang payment.
            if ($decision === 'Approved') {
                $validateStmt = $conn->prepare(
                    "UPDATE payments
                     SET approval_status = 'Approved', status = 'Paid', date_paid = CURDATE()
                     WHERE payment_id = ? AND approval_status = 'Pending'"
                );
            } else {
                $validateStmt = $conn->prepare(
                    "UPDATE payments
                     SET approval_status = 'Rejected'
                     WHERE payment_id = ? AND approval_status = 'Pending'"
                );
            }
            $validateStmt->bind_param('i', $paymentId);
            $validateStmt->execute();
            if ($validateStmt->affected_rows > 0) {
                logAudit($conn, $userId, 'validate_payment', $decision . ' ang payment (payment_id=' . $paymentId . ').');
                if ($paymentInfo) {
                    $paymentLabel = trim((string) ($paymentInfo['description'] ?? ''));
                    if ($paymentLabel === '') {
                        $paymentLabel = 'dues';
                    }
                    $paymentAmount = number_format((float) ($paymentInfo['amount'] ?? 0), 2);
                    if ($decision === 'Approved') {
                        notifyUser(
                            $conn,
                            (int) $paymentInfo['user_id'],
                            'payment',
                            'Na-approve ang payment mo',
                            'Na-approve ang payment mo para sa ' . $paymentLabel . ' (₱' . $paymentAmount . '). Na-mark ito bilang Paid.',
                            'payments.php'
                        );
                    } else {
                        notifyUser(
                            $conn,
                            (int) $paymentInfo['user_id'],
                            'payment',
                            'Na-reject ang payment mo',
                            'Na-reject ang payment submission mo para sa ' . $paymentLabel . ' (₱' . $paymentAmount . '). Puwede kang magbayad uli.',
                            'payments.php'
                        );
                    }
                }
                $_SESSION['payment_message'] = $decision === 'Approved'
                    ? 'Na-approve at na-mark ang payment bilang Paid.'
                    : 'Na-reject ang payment submission.';
            } else {
                $_SESSION['payment_message'] = 'Na-validate na ang payment na ito o hindi ito makita.';
            }
            header('Location: payments.php');
            exit;
        }
    } else {
        http_response_code(403);
        $error = 'Walang pahintulot para sa payment action na ito.';
    }
}

// Kinukuha lamang ang sariling payment history ng resident o ang buong listahan para sa staff.
$balance = 0.0;
$pendingPayments = 0;
$paymentHistory = null;
$allPayments = null;
$residents = null;
$selectedResidentLabel = '';
$paymentPageSize = 10;
$paymentPage = paginationPage();
$paymentTotalPages = 1;
$paymentSearch = isset($_GET['q']) && is_string($_GET['q']) ? trim($_GET['q']) : '';
$paymentSearchPattern = '%' . $paymentSearch . '%';
$paymentPaginationParams = $paymentSearch === '' ? [] : ['q' => $paymentSearch];

if ($role === 'resident' && $residentId > 0) {
    // Ang Pending na submission ay hindi na binibilang sa babayaran.
    $balanceStmt = $conn->prepare(
        "SELECT COALESCE(SUM(amount), 0) AS total
         FROM payments WHERE resident_id = ? AND status = 'Unpaid'
           AND (approval_status IS NULL OR approval_status = 'Rejected')"
    );
    $balanceStmt->bind_param('i', $residentId);
    $balanceStmt->execute();
    $balance = (float) $balanceStmt->get_result()->fetch_assoc()['total'];

    $pendingStmt = $conn->prepare(
        "SELECT COUNT(*) AS c FROM payments
         WHERE resident_id = ? AND status = 'Unpaid' AND approval_status = 'Pending'"
    );
    $pendingStmt->bind_param('i', $residentId);
    $pendingStmt->execute();
    $pendingPayments = (int) $pendingStmt->get_result()->fetch_assoc()['c'];

    $paymentSearchSql = $paymentSearch === ''
        ? ''
        : " AND CONCAT_WS(' ', description, amount, date_paid, due_date, status, approval_status,
                           payment_method, payment_provider, payment_reference) LIKE ?";
    $paymentCountStmt = $conn->prepare(
        'SELECT COUNT(*) AS total FROM payments WHERE resident_id = ?' . $paymentSearchSql
    );
    if ($paymentSearch === '') {
        $paymentCountStmt->bind_param('i', $residentId);
    } else {
        $paymentCountStmt->bind_param('is', $residentId, $paymentSearchPattern);
    }
    $paymentCountStmt->execute();
    $paymentCount = (int) $paymentCountStmt->get_result()->fetch_assoc()['total'];
    $paymentTotalPages = max(1, (int) ceil($paymentCount / $paymentPageSize));
    $paymentPage = min($paymentPage, $paymentTotalPages);
    $paymentOffset = ($paymentPage - 1) * $paymentPageSize;
    $paymentHistorySearchSql = $paymentSearch === ''
        ? ''
        : " AND CONCAT_WS(' ', description, amount, date_paid, due_date, status, approval_status,
                           payment_method, payment_provider, payment_reference) LIKE ?";
    $historyStmt = $conn->prepare(
        'SELECT payment_id, description, amount, date_paid, due_date, status, approval_status,
                payment_method, payment_provider, payment_reference, payment_proof
         FROM payments WHERE resident_id = ?' . $paymentHistorySearchSql . '
         ORDER BY payment_id DESC
         LIMIT ' . $paymentPageSize . ' OFFSET ' . $paymentOffset
    );
    if ($paymentSearch === '') {
        $historyStmt->bind_param('i', $residentId);
    } else {
        $historyStmt->bind_param('is', $residentId, $paymentSearchPattern);
    }
    $historyStmt->execute();
    $paymentHistory = $historyStmt->get_result();
} elseif ($isStaff) {
    $residents = $conn->query(
        "SELECT resident_id, blk, lot
         FROM residents
         WHERE status = 'active' AND blk BETWEEN 1 AND 100 AND lot BETWEEN 1 AND 100
         ORDER BY blk, lot, resident_id"
    );
    $postedResidentId = filter_var(
        $_POST['resident_id'] ?? null,
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1]]
    );
    if ($postedResidentId !== false) {
        $selectedResidentStmt = $conn->prepare(
            "SELECT blk, lot FROM residents
             WHERE resident_id = ? AND status = 'active'
               AND blk BETWEEN 1 AND 100 AND lot BETWEEN 1 AND 100"
        );
        $selectedResidentStmt->bind_param('i', $postedResidentId);
        $selectedResidentStmt->execute();
        $selectedResident = $selectedResidentStmt->get_result()->fetch_assoc();
        if ($selectedResident) {
            $selectedResidentLabel = 'Blk ' . (int) $selectedResident['blk']
                . ' Lot ' . (int) $selectedResident['lot'];
        }
    }
    $paymentSearchSql = $paymentSearch === ''
        ? ''
        : " WHERE CONCAT_WS(' ', p.description, p.amount, p.date_paid, p.due_date, p.status,
                            p.approval_status, p.payment_method, p.payment_provider,
                            p.payment_reference, u.full_name, r.block_lot) LIKE ?";
    $paymentCountStmt = $conn->prepare(
        'SELECT COUNT(*) AS total
         FROM payments p
         JOIN residents r ON p.resident_id = r.resident_id
         JOIN users u ON r.user_id = u.user_id' . $paymentSearchSql
    );
    if ($paymentSearch === '') {
        $paymentCountStmt->execute();
    } else {
        $paymentCountStmt->bind_param('s', $paymentSearchPattern);
        $paymentCountStmt->execute();
    }
    $paymentCount = (int) $paymentCountStmt->get_result()->fetch_assoc()['total'];
    $paymentTotalPages = max(1, (int) ceil($paymentCount / $paymentPageSize));
    $paymentPage = min($paymentPage, $paymentTotalPages);
    $paymentOffset = ($paymentPage - 1) * $paymentPageSize;
    $allPaymentSearchSql = $paymentSearch === ''
        ? ''
        : " WHERE CONCAT_WS(' ', p.description, p.amount, p.date_paid, p.due_date, p.status,
                            p.approval_status, p.payment_method, p.payment_provider,
                            p.payment_reference, u.full_name, r.block_lot) LIKE ?";
    $allPaymentsStmt = $conn->prepare(
        'SELECT p.payment_id, p.description, p.amount, p.date_paid, p.due_date, p.status,
                p.approval_status, p.payment_method, p.payment_provider,
                p.payment_reference, p.payment_proof,
                u.full_name, r.block_lot
         FROM payments p
         JOIN residents r ON p.resident_id = r.resident_id
         JOIN users u ON r.user_id = u.user_id
         ' . $allPaymentSearchSql . '
         ORDER BY p.payment_id DESC
         LIMIT ' . $paymentPageSize . ' OFFSET ' . $paymentOffset
    );
    if ($paymentSearch !== '') {
        $allPaymentsStmt->bind_param('s', $paymentSearchPattern);
    }
    $allPaymentsStmt->execute();
    $allPayments = $allPaymentsStmt->get_result();
}

require_once 'includes/header.php';
?>
<div class="page-header"><h2>Payments</h2></div>
<?php if ($error !== ''): ?>
  <p class="alert" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>
<?php if ($message !== ''): ?>
  <p class="alert alert-success" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<?php if ($role === 'resident'): ?>
  <?php if ($residentId < 1): ?>
    <section class="card"><p>Wala pang resident profile na naka-link sa account mo. Makipag-ugnayan sa HOA officer.</p></section>
  <?php else: ?>
    <section class="card balance-card">
      <div><span class="muted">Outstanding Balance</span><strong>₱<?= number_format($balance, 2) ?></strong></div>
      <?php if ($balance > 0): ?>
        <form action="payments.php" method="post" enctype="multipart/form-data">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <div class="form-field">
            <label for="residentPaymentOption">Payment Option</label>
            <select id="residentPaymentOption" name="payment_option" required>
              <option value="">-- Piliin ang payment option --</option>
              <option value="Cash">Cash</option>
              <option value="GCash">GCash</option>
              <option value="Online Bank">Online Bank</option>
            </select>
          </div>
          <div class="form-field" id="onlineReferenceField" hidden>
            <label for="paymentReference">Transaction / Reference Number</label>
            <input id="paymentReference" type="text" name="payment_reference" maxlength="100" inputmode="numeric" pattern="[0-9]{1,100}" title="Digits only." placeholder="Digits only" aria-describedby="paymentReferenceHelp">
            <small id="paymentReferenceHelp">Digits only. GCash reference numbers must be 13 digits.</small>
          </div>
          <div class="form-field" id="onlineProofField">
            <label for="paymentProof">Proof of Payment <span class="muted">(required for online, optional for Cash)</span></label>
            <input id="paymentProof" type="file" name="payment_proof" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf">
          </div>
          <button type="submit" name="pay_now" value="1" class="btn btn-primary">Pay Now</button>
        </form>
      <?php elseif ($pendingPayments > 0): ?>
        <span>Naghihintay pa ng admin validation ang payment mo.</span>
      <?php else: ?>
        <span class="balance-confirmation">All dues settled</span>
      <?php endif; ?>
    </section>
    <section class="card">
      <div class="card-head">
        <h3>Payment History</h3>
        <form action="payments.php" method="get" class="pagination-search">
          <input type="search" id="searchInput" name="q" value="<?= htmlspecialchars($paymentSearch, ENT_QUOTES, 'UTF-8') ?>" placeholder="Mag-search sa history..." aria-label="Search payment history">
          <button type="submit" class="btn btn-small">Search</button>
        </form>
      </div>
      <div class="table-wrap resident-payment-table">
        <table class="table" id="dataTable">
          <thead><tr><th>Due Date</th><th>Date Paid</th><th>Description</th><th>Amount</th><th>Payment Option</th><th>Status</th></tr></thead>
          <tbody>
            <?php while ($payment = $paymentHistory->fetch_assoc()): ?>
              <tr>
                <td><?= $payment['due_date'] ? htmlspecialchars(date('M d, Y', strtotime($payment['due_date'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                <td><?= $payment['date_paid'] ? htmlspecialchars(date('M d, Y', strtotime($payment['date_paid'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                <td><?= htmlspecialchars($payment['description'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>₱<?= number_format((float) $payment['amount'], 2) ?></td>
                <td>
                  <?= htmlspecialchars(!empty($payment['payment_provider']) ? $payment['payment_provider'] : ($payment['payment_method'] ?? '—'), ENT_QUOTES, 'UTF-8') ?>
                </td>
                <td>
                  <?php if (!empty($payment['approval_status'])): ?>
                    <span class="badge"><?= htmlspecialchars($payment['approval_status'], ENT_QUOTES, 'UTF-8') ?></span>
                  <?php else: ?>
                    <span class="badge badge-<?= strtolower(htmlspecialchars($payment['status'], ENT_QUOTES, 'UTF-8')) ?>"><?= htmlspecialchars($payment['status'], ENT_QUOTES, 'UTF-8') ?></span>
                  <?php endif; ?>
                  <?php if ($payment['status'] === 'Unpaid' && ($payment['approval_status'] ?? '') === 'Pending' && empty($payment['payment_proof'])): ?>
                    <form action="payments.php" method="post" enctype="multipart/form-data" class="payment-proof-upload-form">
                      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                      <input type="hidden" name="payment_id" value="<?= (int) $payment['payment_id'] ?>">
                      <label for="paymentProof<?= (int) $payment['payment_id'] ?>">Attach missing proof</label>
                      <input id="paymentProof<?= (int) $payment['payment_id'] ?>" type="file" name="payment_proof" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf" required>
                      <button type="submit" name="upload_payment_proof" value="1" class="btn btn-small">Upload Proof</button>
                    </form>
                  <?php endif; ?>
                  <a href="receipt.php?payment_id=<?= (int) $payment['payment_id'] ?>" target="_blank" rel="noopener" class="btn btn-small">Resibo</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <?php renderPagination($paymentPage, $paymentTotalPages, $paymentPaginationParams); ?>
    </section>
  <?php endif; ?>
<?php elseif ($isStaff): ?>
  <section class="card">
    <h3>Record Payment</h3>
    <form class="form-grid" action="payments.php" method="post">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
      <div class="form-field">
        <label for="paymentResidentSearch">Resident (Block &amp; Lot)</label>
        <input id="paymentResidentSearch" type="search" list="paymentResidentOptions" autocomplete="off" value="<?= htmlspecialchars($selectedResidentLabel, ENT_QUOTES, 'UTF-8') ?>" placeholder="I-type ang Block at Lot, hal. Blk 4 Lot 5" aria-describedby="paymentResidentHelp" required>
        <input id="paymentResidentId" type="hidden" name="resident_id" value="<?= htmlspecialchars((string) ($_POST['resident_id'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        <datalist id="paymentResidentOptions">
          <?php while ($resident = $residents->fetch_assoc()): ?>
            <?php $residentLabel = 'Blk ' . (int) $resident['blk'] . ' Lot ' . (int) $resident['lot']; ?>
            <option value="<?= htmlspecialchars($residentLabel, ENT_QUOTES, 'UTF-8') ?>" data-resident-id="<?= (int) $resident['resident_id'] ?>"></option>
          <?php endwhile; ?>
        </datalist>
        <small id="paymentResidentHelp">Habang nagta-type, piliin ang tamang Block at Lot mula sa mga mungkahi.</small>
      </div>
      <div class="form-field">
        <label for="paymentDescription">Description</label>
        <input id="paymentDescription" type="text" name="description" maxlength="100" value="<?= htmlspecialchars($description, ENT_QUOTES, 'UTF-8') ?>" placeholder="Hal. Other Fees: gate repair" required>
      </div>
      <div class="form-field">
        <label for="paymentAmount">Amount</label>
        <input id="paymentAmount" type="number" step="0.01" min="0.01" max="99999999.99" name="amount" value="1000" required>
      </div>
      <div class="form-field">
        <label for="dueDate">Date Need to Pay</label>
        <input id="dueDate" type="date" name="due_date" value="<?= date('Y-m-d', strtotime('+30 days')) ?>" required>
      </div>
      <div class="form-actions"><button type="submit" name="record_payment" value="1" class="btn btn-primary">Record Payment</button></div>
    </form>
  </section>
  <section class="card">
    <div class="card-head">
      <h3>All Payments</h3>
      <?php if ($role === 'admin'): ?>
        <form action="payments.php" method="post" onsubmit="return confirm('Buburahin ang LAHAT ng payment history. Sigurado ka?');">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <button type="submit" name="clear_payments" value="1" class="btn btn-danger btn-small">Burahin ang Lahat ng History</button>
        </form>
      <?php endif; ?>
      <form action="payments.php" method="get" class="pagination-search">
        <input type="search" id="searchInput" name="q" value="<?= htmlspecialchars($paymentSearch, ENT_QUOTES, 'UTF-8') ?>" placeholder="Mag-search ng pangalan..." aria-label="Search all payments">
        <button type="submit" class="btn btn-small">Search</button>
      </form>
    </div>
    <div class="table-wrap admin-responsive-table">
      <table class="table" id="dataTable">
        <thead><tr><th>Date Need to Pay</th><th>Member</th><th>Block/Lot</th><th>Description</th><th>Amount</th><th>Validation</th><th>Action</th></tr></thead>
        <tbody>
          <?php while ($payment = $allPayments->fetch_assoc()): ?>
            <tr>
              <td><?= $payment['due_date'] ? htmlspecialchars(date('M d, Y', strtotime($payment['due_date'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
              <td><?= htmlspecialchars($payment['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($payment['block_lot'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($payment['description'], ENT_QUOTES, 'UTF-8') ?></td>
              <td>₱<?= number_format((float) $payment['amount'], 2) ?></td>
              <td>
                <?php if (!empty($payment['approval_status'])): ?>
                  <?= htmlspecialchars($payment['approval_status'], ENT_QUOTES, 'UTF-8') ?>
                <?php else: ?>
                  <?= htmlspecialchars($payment['status'], ENT_QUOTES, 'UTF-8') ?>
                <?php endif; ?>
                <?php if (!empty($payment['payment_reference'])): ?>
                  <div class="payment-ref">Ref: <?= htmlspecialchars($payment['payment_reference'], ENT_QUOTES, 'UTF-8') ?></div>
                <?php endif; ?>
                <?php if (!empty($payment['payment_proof'])): ?>
                  <?php
                    $proofUrl = 'download_payment_proof.php?payment_id=' . (int) $payment['payment_id'];
                    $proofExtension = strtolower(pathinfo((string) $payment['payment_proof'], PATHINFO_EXTENSION));
                  ?>
                  <?php if (in_array($proofExtension, ['jpg', 'jpeg', 'png', 'webp'], true)): ?>
                    <div>
                      <img class="payment-proof-preview" src="<?= htmlspecialchars($proofUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Payment proof — i-double click para palakihin" loading="lazy" data-proof-url="<?= htmlspecialchars($proofUrl, ENT_QUOTES, 'UTF-8') ?>" title="I-double click para palakihin">
                    </div>
                  <?php else: ?>
                    <div>
                      <a href="<?= htmlspecialchars($proofUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener" class="btn btn-small">Buksan ang file</a>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
              </td>
              <td>
                <?php if (($payment['approval_status'] ?? '') === 'Pending'): ?>
                  <form action="payments.php" method="post" class="confirm-form" data-confirm="Approve at markahan bilang Paid ang payment na ito?" style="display:inline;">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="payment_id" value="<?= (int) $payment['payment_id'] ?>">
                    <input type="hidden" name="decision" value="Approved">
                    <button type="submit" name="validate_payment" value="1" class="btn btn-small">Approve</button>
                  </form>
                  <form action="payments.php" method="post" class="confirm-form" data-confirm="Reject ang payment submission na ito?" style="display:inline;">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="payment_id" value="<?= (int) $payment['payment_id'] ?>">
                    <input type="hidden" name="decision" value="Rejected">
                    <button type="submit" name="validate_payment" value="1" class="btn btn-small">Reject</button>
                  </form>
                <?php elseif (($payment['approval_status'] ?? '') === 'Approved'): ?>
                  <a href="receipt.php?payment_id=<?= (int) $payment['payment_id'] ?>" target="_blank" rel="noopener" class="btn btn-small">Resibo</a>
                <?php else: ?>
                  <form action="payments.php" method="post" class="confirm-form" data-confirm="Tatanggalin ang payment history na ito. Magpatuloy?">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="payment_id" value="<?= (int) $payment['payment_id'] ?>">
                    <button type="submit" name="delete_payment" value="1" class="btn btn-small">Delete History</button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <?php renderPagination($paymentPage, $paymentTotalPages, $paymentPaginationParams); ?>
  </section>
  <!-- Proof viewer: i-double click ang thumbnail para palakihin nang hindi umaalis sa page. -->
  <div class="proof-modal" id="proofModal" hidden>
    <div class="proof-modal-backdrop" data-close-proof></div>
    <div class="proof-modal-box" role="dialog" aria-modal="true" aria-label="Payment proof">
      <button type="button" class="proof-modal-close" data-close-proof aria-label="Isara">&times;</button>
      <img id="proofModalImg" src="" alt="Payment proof">
    </div>
  </div>
  <script>
  (function () {
    var modal = document.getElementById('proofModal');
    var modalImg = document.getElementById('proofModalImg');
    if (!modal || !modalImg) return;
    function openProof(url) {
      modalImg.src = url;
      modal.hidden = false;
      document.body.style.overflow = 'hidden';
    }
    function closeProof() {
      modal.hidden = true;
      modalImg.src = '';
      document.body.style.overflow = '';
    }
    document.querySelectorAll('.payment-proof-preview').forEach(function (img) {
      img.addEventListener('dblclick', function () {
        openProof(img.getAttribute('data-proof-url') || img.src);
      });
    });
    modal.querySelectorAll('[data-close-proof]').forEach(function (el) {
      el.addEventListener('click', closeProof);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !modal.hidden) closeProof();
    });
  })();
  </script>
<?php else: ?>
  <section class="card"><p>Walang pahintulot na makita ang payments page.</p></section>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
