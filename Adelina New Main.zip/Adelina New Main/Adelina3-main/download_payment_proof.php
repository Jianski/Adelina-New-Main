<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['admin', 'officer'], true)) {
    http_response_code(403);
    exit('Walang pahintulot.');
}

$paymentId = filter_var($_GET['payment_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($paymentId === false) {
    http_response_code(400);
    exit('Invalid payment ID.');
}

$stmt = $conn->prepare('SELECT payment_proof, payment_proof_data, payment_proof_mime FROM payments WHERE payment_id = ?');
$stmt->bind_param('i', $paymentId);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();

if (!$payment || empty($payment['payment_proof'])) {
    http_response_code(404);
    exit('Hindi makita ang payment proof.');
}

$proofFile = (string) ($payment['payment_proof'] ?? '');

// Tanging server-generated na pangalan lang ang tinatanggap, tulad ng
// ibang download script, para hindi magamit ang filename sa path traversal.
if (!preg_match('/\A[a-f0-9]{32}\.(?:jpg|jpeg|png|webp|pdf)\z/i', $proofFile)) {
    http_response_code(404);
    exit('Hindi makita ang payment proof file.');
}

// Nasa database na ang proof ng mga bagong upload; ang lumang file
// sa folder pa rin ang gagamitin kapag walang naka-save na bytes.
$proofData = $payment['payment_proof_data'] ?? null;
$proofMime = $payment['payment_proof_mime'] ?? null;

if ($proofData !== null) {
    $extension = strtolower(pathinfo($proofFile, PATHINFO_EXTENSION));
    $mimeTypes = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'webp' => 'image/webp',
        'pdf' => 'application/pdf',
    ];
    $mimeType = is_string($proofMime) && in_array($proofMime, $mimeTypes, true)
        ? $proofMime
        : ($mimeTypes[$extension] ?? 'application/octet-stream');
    header('Content-Type: ' . $mimeType);
    header('Content-Disposition: inline; filename="' . $proofFile . '"');
    header('X-Content-Type-Options: nosniff');
    header('Content-Length: ' . strlen($proofData));
    echo $proofData;
    exit;
}

$directory = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'hoa-payment-proofs';
$path = $directory . DIRECTORY_SEPARATOR . $proofFile;
if (!is_file($path) || !is_readable($path)) {
    http_response_code(404);
    exit('Hindi makita ang payment proof file.');
}

$extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$mimeTypes = [
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'webp' => 'image/webp',
    'pdf' => 'application/pdf',
];
header('Content-Type: ' . ($mimeTypes[$extension] ?? 'application/octet-stream'));
header('Content-Disposition: inline; filename="' . basename($path) . '"');
header('X-Content-Type-Options: nosniff');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;
